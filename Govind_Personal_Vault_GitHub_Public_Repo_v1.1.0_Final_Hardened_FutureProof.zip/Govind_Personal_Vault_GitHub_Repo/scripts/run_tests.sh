#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
command -v gradle >/dev/null || { echo "Gradle is not installed on PATH." >&2; exit 1; }
gradle --no-daemon --stacktrace -p "$PROJECT_DIR" :app:testReleaseUnitTest :app:lintRelease
