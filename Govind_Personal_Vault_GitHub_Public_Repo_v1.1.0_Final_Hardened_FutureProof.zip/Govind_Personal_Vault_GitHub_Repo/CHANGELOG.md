# Changelog

## 1.1.0 — Phase 2 Media Vault

- Migrated the app to a Gradle/AndroidX build while retaining the zero-layout-XML programmatic UI.
- Added a secure Media Vault for photos, videos, and audio.
- Added multi-document import through the Activity Result API without broad storage permissions.
- Added the GVM2 seekable encrypted format with authenticated header, per-file HKDF keys, and independent AES-256-GCM chunks.
- Added bounded, stream-based import so complete media files are never loaded into RAM.
- Added encrypted metadata and encrypted thumbnail storage in SQLite schema version 2.
- Preserved the existing `vault_items` table and Phase 1 data through an additive migration.
- Added gallery filters, 300 ms search debounce, encrypted thumbnails, type icons, progress, and empty states.
- Added a secure sampled image viewer.
- Added AndroidX Media3/ExoPlayer audio/video playback through `EncryptedCipherDataSource` with on-the-fly authenticated decryption.
- Added direct MediaStore export without plaintext temporary files.
- Added permanent media deletion and stale temporary-file cleanup.
- Added media count/navigation to the main vault screen.
- Added Phase 2 unit tests, source-security checks, repository-secret scanning, and APK verification assertions.
- Increased versionCode from 2 to 3 and versionName from 1.0.1 to 1.1.0.

## 1.0.1

- Fixed startup database initialization on devices that classify `PRAGMA secure_delete=ON` as a query.
- Debounced vault search and added an in-field clear control.
- Added deterministic circular avatars, richer empty states, smooth transitions, and automatic editor focus.
- Simplified encrypted draft persistence without changing the Phase 1 encryption model.

## 1.1.0 security-hardening update
- Added VaultSession epoch invalidation for long-running media operations.
- Reused bounded playback buffers to reduce 4K seek allocation churn.
- Added fail-closed epoch checks before and after authenticated chunk decryption.
- Added aggressive media filesystem/SQLite crash reconciliation.
- Added internal-storage preflight and runtime low-space checks.
- Added throttled import progress delivery.
- Added programmatic multi-audio track selection.
- Added safe unsupported-codec messages and immediate player release.
- Added immediate screen-off vault lock and player shutdown.
