# Changelog

## 1.2.6 (version code 11)

- Opening a photo, video, audio, or document now fills the screen with the file. Title, filename, MIME, and hint text are removed from the viewer.
- Back, export, and delete stay as thin overlays. Zoom, swipe, playback, encryption, and package ID are unchanged.

## 1.2.5 (version code 10)


- Premium visual refresh: warmer ink surfaces, jewel mint accent, hairline cards, outlined secondary buttons, and circular back control.
- Lock, dashboard, media, documents, player overlay, and settings inherit the new design system. Feature logic, encryption, package ID, and signing are unchanged.
- Screenshot protection remains off for QA.

## 1.2.4 (version code 9)

- Settings now shows the real installed app version instead of a hardcoded 1.0.0.
- Player overlay is compact: seek and times share one row, Fit/Zoom/Fill sits with the transport buttons.
- Video controls auto-hide after a few seconds in portrait and landscape; tap the video to bring them back.
- Tall/portrait videos stay on Fit by default so faces are not cropped in landscape Zoom.
- Long photo and media names ellipsize in the middle instead of wrapping through the file extension.
- Duplicate pinch-zoom hint removed from the image viewer. Screenshot protection remains off for QA.

## 1.2.3 (version code 8)

- Temporarily disabled FLAG_SECURE screenshot blocking so device screenshots can be captured for QA. Set `BaseActivity.BLOCK_SCREENSHOTS` back to true before the final release.
- Encrypted audio/video player now autoplays, uses a faster start buffer, and shows a buffering spinner.
- Player controls sit as an overlay on the media. Tap play/pause, double-tap left/right to skip 10s, horizontal swipe to seek, left-half vertical swipe for brightness, right-half vertical swipe for volume.
- Speed options include 0.75×. Encryption, package ID, signing, and permissions are unchanged.

## 1.2.2 (version code 7)


- Encrypted photos can be pinched to zoom, dragged to pan, double-tapped to zoom, and slid left/right to the next photo.
- Encrypted documents now open inside the vault: PDF pages, text files, and Office/OpenDocument text previews.
- PDF viewing uses an in-memory memfd + Android PdfRenderer. No plaintext document file is written to disk, and files are still not handed to external apps.
- Document pages can be pinched to zoom and slid to the next page. Text previews support pinch-to-resize.
- Export and delete remain available. Package ID, signing, encryption format, and permissions are unchanged.

## 1.2.1 (version code 5)


- Removed the fullscreen landscape bottom gap by suppressing retained system-gesture padding while immersive video is active.
- Landscape video now defaults to Zoom so common 16:9 content fills tablet displays; Fit and Fill remain available from Resize.
- Added secure in-player vertical swipe controls: left half adjusts per-window brightness and right half adjusts media volume.
- Added an on-screen percentage overlay that disappears automatically after the gesture.
- No storage, network, or global settings permission was added. Core encrypted streaming and session-lock behavior are unchanged.

## 1.2.0 — Landscape UI, immersive playback, and encrypted documents

- Increased versionCode from 3 to 4 and versionName from 1.1.0 to 1.2.0.
- Reworked the programmatic dashboard into a single scrollable `ListView` surface so dashboard controls and vault items remain reachable in landscape without nesting a list inside a `ScrollView`.
- Added a fourth dashboard counter and navigation category for Documents.
- Added `DocumentsVaultActivity` with multi-select Storage Access Framework import, search, encrypted-document list, import progress, and empty state.
- Added `SecureDocumentActivity` for protected metadata, direct authenticated export to Downloads, and permanent encrypted-file deletion.
- Reused the existing chunked AES-256-GCM encrypted-file format and encrypted SQLite metadata for documents without changing the database schema or existing media format.
- Kept media and documents separated: media lists exclude documents, and the Documents picker rejects photo/video/audio MIME types.
- Added MediaStore Downloads export for non-media files without plaintext temporary files or external `ACTION_VIEW` handoff.
- Replaced the video surface shell with programmatic Media3 `PlayerView` integration while retaining a secure `SurfaceView`.
- Added immersive landscape playback with hidden system bars and hidden app title/metadata chrome.
- Added Fit, Zoom, and Fill video resize controls and playback-control auto-hide during active video playback.
- Added security-audit and final-APK regression checks for the new document and fullscreen-player classes/features.

## 1.1.0 — Phase 2 Media Vault

- Migrated the app to a Gradle/AndroidX build while retaining the zero-layout-XML programmatic UI.
- Added a secure Media Vault for photos, videos, and audio.
- Added multi-document import through the Activity Result API without broad storage permissions.
- Added the GVM2 seekable encrypted format with authenticated header, per-file HKDF keys, and independent AES-256-GCM chunks.
- Added bounded, stream-based import so complete media files are never loaded into RAM.
- Added encrypted metadata and encrypted thumbnail storage in SQLite schema version 2.
- Preserved the existing `vault_items` table and Phase 1 data through an additive migration.
- Added gallery filters, 300 ms search debounce, encrypted thumbnails, type icons, progress, and empty states.
- Added a secure sampled image viewer.
- Added AndroidX Media3/ExoPlayer audio/video playback through `EncryptedCipherDataSource` with on-the-fly authenticated decryption.
- Added direct MediaStore export without plaintext temporary files.
- Added permanent media deletion and stale temporary-file cleanup.
- Added media count/navigation to the main vault screen.
- Added Phase 2 unit tests, source-security checks, repository-secret scanning, and APK verification assertions.
- Increased versionCode from 2 to 3 and versionName from 1.0.1 to 1.1.0.

## 1.0.1

- Fixed startup database initialization on devices that classify `PRAGMA secure_delete=ON` as a query.
- Debounced vault search and added an in-field clear control.
- Added deterministic circular avatars, richer empty states, smooth transitions, and automatic editor focus.
- Simplified encrypted draft persistence without changing the Phase 1 encryption model.

## 1.1.0 security-hardening update
- Added VaultSession epoch invalidation for long-running media operations.
- Reused bounded playback buffers to reduce 4K seek allocation churn.
- Added fail-closed epoch checks before and after authenticated chunk decryption.
- Added aggressive media filesystem/SQLite crash reconciliation.
- Added internal-storage preflight and runtime low-space checks.
- Added throttled import progress delivery.
- Added programmatic multi-audio track selection.
- Added safe unsupported-codec messages and immediate player release.
- Added immediate screen-off vault lock and player shutdown.

## Build pipeline correction (same app version 1.1.0 / code 3)
- Made `scripts/run_tests.sh` compatible with projects where AGP does not create `testReleaseUnitTest` because no unit-test source set is present.
- The test gate now always compiles release Java sources and runs release lint, and automatically runs release unit tests whenever that task exists.

## Build pipeline correction 2 (same app version 1.1.0 / code 3)
- Removed the source-manifest `<uses-sdk>` declaration; minSdk and targetSdk remain centrally controlled by `app/version.properties` through `app/build.gradle`.
- Removed the source-manifest `package` attribute; namespace and application ID remain `com.govind.personalvault` in Gradle.
- Updated the source-security audit to validate SDK and identity configuration at the Gradle layer and reject future manifest regressions.

## 1.1.0 final audited build candidate

- Pin GitHub builds to Gradle 9.5.0 with official `gradle/actions/setup-gradle@v6`.
- Execute debug JVM unit tests under AGP 9 instead of requesting the absent release unit-test task.
- Keep release Java compilation and release lint as mandatory gates.
- Work around the AGP 9.3 `BidiSpoofing` lint-detector crash only, backed by a deterministic
  repository-wide Unicode bidirectional-control scanner.
- Add epoch-bound, reusable-buffer authenticated decryption to `EncryptedMediaInputStream`.
- Add writer epoch checks, export cancellation cleanup, cancelled DB-result wiping, secure dynamic
  receiver registration and immediate thumbnail-envelope byte wiping.

## Media3 lint opt-in correction (same app version 1.1.0 / code 3)

- Replaced app-owned `@UnstableApi` declarations with the correct application-side
  `@OptIn(markerClass = UnstableApi.class)` annotation.
- Prevents `UnsafeOptInUsageError` at `MediaVaultActivity.java:348` while keeping
  Media3 unstable API usage explicit and reviewable.
- Added a security-audit regression guard that rejects future app-owned `@UnstableApi` declarations.

## Unicode audit scope correction (same app version 1.1.0 / code 3)

- Restricted the custom bidirectional-control scan to repository-authored files.
- Excluded generated `build`, Gradle, IDE and distribution folders so Android pseudo-locale resources
  containing legitimate U+200E/U+200F marks do not fail the security gate.
- Source Java/XML/Gradle/script files remain protected by the same fail-closed scanner.

## v1.1.0 signing configuration correction
- Replaced ambiguous Groovy signing DSL method-style statements with explicit property assignments.
- Renamed signing environment variables in the Gradle script so they cannot shadow SigningConfig properties.
- Added an audit regression guard for the exact `String.call()` signing-config failure.
