package com.govind.personalvault;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.govind.personalvault.data.VaultDb;
import com.govind.personalvault.media.MediaRepository;
import com.govind.personalvault.model.MediaItemRecord;
import com.govind.personalvault.security.VaultSession;
import com.govind.personalvault.ui.Ui;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

/** Secure metadata/detail screen for an encrypted document. */
public final class SecureDocumentActivity extends BaseActivity {
    private String mediaId;
    private TextView name;
    private TextView detail;
    private Button export;
    private MediaItemRecord record;
    private VaultDb.Task metadataTask;
    private MediaRepository.Task actionTask;
    private boolean active;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        mediaId = getIntent().getStringExtra("media_id");
        if (mediaId == null || mediaId.trim().isEmpty()) {
            finish();
            return;
        }
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        active = VaultSession.isUnlocked();
        if (active) load();
    }

    @Override protected void onStop() {
        active = false;
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (metadataTask != null) metadataTask.cancel();
        if (actionTask != null) actionTask.cancel();
        clearSensitiveUi();
        super.onDestroy();
    }

    @Override protected void clearSensitiveUi() {
        if (record != null) record.clearSensitive();
        record = null;
        if (name != null) name.setText("Encrypted document");
        if (detail != null) detail.setText("Vault locked");
        if (export != null) export.setEnabled(false);
    }

    private void build() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(palette.bg);
        root.addView(topBar(
                "Secure document",
                "Authenticated encrypted storage",
                true,
                null,
                null));

        LinearLayout body = Ui.vertical(this);
        body.setPadding(Ui.dp(this, 18), Ui.dp(this, 12), Ui.dp(this, 18), Ui.dp(this, 18));

        LinearLayout card = Ui.card(this);
        TextView icon = Ui.text(this, "▤", 62, palette.accent);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon, new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 112)));

        name = Ui.title(this, "Opening encrypted document…");
        name.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(name, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));

        detail = Ui.text(this, "Reading protected metadata", 13, palette.muted);
        detail.setGravity(Gravity.CENTER_HORIZONTAL);
        detail.setLineSpacing(0, 1.16f);
        card.addView(detail, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));

        TextView security = Ui.text(
                this,
                "This app does not create a plaintext temporary preview. Exporting writes an authenticated decrypted copy directly to Downloads; the encrypted vault copy remains protected.",
                13,
                palette.muted);
        security.setLineSpacing(0, 1.18f);
        security.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(security, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 18, 0, 18));

        export = Ui.primary(this, "Export copy to Downloads");
        export.setEnabled(false);
        export.setOnClickListener(v -> export());
        card.addView(export);

        Button delete = Ui.danger(this, "Delete encrypted document");
        delete.setOnClickListener(v -> startActivity(
                new Intent(this, MediaDeleteConfirmActivity.class)
                        .putExtra("media_id", mediaId)));
        card.addView(delete, Ui.margins(this, Ui.MATCH, Ui.dp(this, 50), 0, 9, 0, 0));

        body.addView(card, centeredPanelParams(680));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(body, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(scroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));
        safeContentView(root);
    }

    private void load() {
        if (metadataTask != null) metadataTask.cancel();
        metadataTask = VaultDb.get(this).getMediaAsync(mediaId, (item, error) -> {
            metadataTask = null;
            if (!active) {
                if (item != null) item.clearSensitive();
                return;
            }
            if (error != null) {
                SecureDocumentActivity.this.error(error);
                finish();
                return;
            }
            if (item == null) {
                message("Document no longer exists");
                finish();
                return;
            }
            if (!item.isDocument()) {
                item.clearSensitive();
                message("This item belongs in the Media Vault");
                finish();
                return;
            }
            if (record != null) record.clearSensitive();
            record = item;
            name.setText(record.originalName);
            detail.setText(typeLabel(record)
                    + " • " + humanSize(record.size)
                    + "\nProtected "
                    + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                            .format(new Date(record.updatedAt)));
            export.setEnabled(true);
        });
    }

    private void export() {
        if (record == null || actionTask != null || !VaultSession.isUnlocked()) return;
        export.setEnabled(false);
        export.setText("Exporting authenticated copy…");
        actionTask = MediaRepository.exportAsync(this, mediaId, (Uri uri, Exception error) -> {
            actionTask = null;
            if (!active) return;
            export.setText("Export copy to Downloads");
            export.setEnabled(true);
            if (error != null) SecureDocumentActivity.this.error(error);
            else message("Exported to Downloads/Govind Personal Vault");
        });
    }

    private static String typeLabel(MediaItemRecord item) {
        String name = item.originalName == null ? "" : item.originalName;
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length() - 1) {
            String extension = name.substring(dot + 1)
                    .toUpperCase(Locale.ROOT)
                    .replaceAll("[^A-Z0-9]", "");
            if (!extension.isEmpty()) return extension;
        }
        return item.mimeType == null ? "DOCUMENT" : item.mimeType;
    }

    private static String humanSize(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        double value = bytes / 1024.0;
        if (value < 1024.0) return String.format(Locale.US, "%.1f KB", value);
        value /= 1024.0;
        if (value < 1024.0) return String.format(Locale.US, "%.1f MB", value);
        return String.format(Locale.US, "%.2f GB", value / 1024.0);
    }
}
