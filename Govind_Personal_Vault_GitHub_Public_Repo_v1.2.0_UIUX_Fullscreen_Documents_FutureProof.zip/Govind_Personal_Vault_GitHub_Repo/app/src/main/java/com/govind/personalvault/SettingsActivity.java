package com.govind.personalvault;

import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.govind.personalvault.security.SecureWork;
import com.govind.personalvault.security.SecurityManager;
import com.govind.personalvault.security.VaultSession;
import com.govind.personalvault.ui.Ui;

import java.util.Arrays;

import javax.crypto.Cipher;

public final class SettingsActivity extends BaseActivity {
    private EditText currentPin;
    private EditText newPin;
    private EditText confirmPin;
    private Button changePin;
    private Button biometric;
    private TextView biometricStatus;
    private SecureWork.Task task;

    @Override protected void onCreate(Bundle state){super.onCreate(state);build();}

    private void build(){
        LinearLayout root=Ui.vertical(this);root.setBackgroundColor(palette.bg);root.addView(topBar("Security settings","Local controls for this device",true,null,null));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout page=Ui.vertical(this);page.setPadding(Ui.dp(this,18),Ui.dp(this,10),Ui.dp(this,18),Ui.dp(this,28));

        LinearLayout posture=Ui.card(this);posture.addView(Ui.badge(this,"PROTECTED",palette.accent));posture.addView(Ui.heading(this,"Security posture"),Ui.margins(this,Ui.MATCH,Ui.WRAP,0,12,0,0));
        TextView controls=Ui.text(this,"• AES-256-GCM field encryption\n• Android Keystore key separation\n• Screenshot and recording protection\n• No Internet permission or cloud backup\n• Immediate background auto-lock",14,palette.muted);controls.setLineSpacing(Ui.dp(this,3),1f);posture.addView(controls,Ui.margins(this,Ui.MATCH,Ui.WRAP,0,8,0,0));page.addView(posture);

        page.addView(Ui.space(this,22));page.addView(Ui.heading(this,"Biometric unlock"));
        biometricStatus=Ui.text(this,"",14,palette.muted);page.addView(biometricStatus,Ui.margins(this,Ui.MATCH,Ui.WRAP,0,5,0,10));
        biometric=Ui.primary(this,"Enable strong biometric");biometric.setOnClickListener(v->toggleBiometric());page.addView(biometric);updateBiometricStatus();

        page.addView(Ui.space(this,22));page.addView(Ui.heading(this,"Change PIN"));
        TextView pinInfo=Ui.text(this,"Changing the PIN re-wraps the vault key. It does not decrypt and rewrite every record.",14,palette.muted);page.addView(pinInfo,Ui.margins(this,Ui.MATCH,Ui.WRAP,0,5,0,3));
        currentPin=Ui.pin(this,"Current PIN");newPin=Ui.pin(this,"New 6–12 digit PIN");confirmPin=Ui.pin(this,"Confirm new PIN");field(page,"Current PIN",currentPin);field(page,"New PIN",newPin);field(page,"Confirm new PIN",confirmPin);
        changePin=Ui.primary(this,"Change PIN securely");changePin.setOnClickListener(v->changePin());page.addView(changePin,Ui.margins(this,Ui.MATCH,Ui.dp(this,52),0,16,0,0));

        page.addView(Ui.space(this,22));page.addView(Ui.heading(this,"Session"));Button lock=Ui.danger(this,"Lock vault now");lock.setOnClickListener(v->{VaultSession.lock();finish();});page.addView(lock,Ui.margins(this,Ui.MATCH,Ui.dp(this,52),0,10,0,0));
        LinearLayout about=Ui.card(this);about.addView(Ui.heading(this,"Govind Personal Vault 1.0.0"));TextView aboutText=Ui.text(this,"Android 12+ • fully offline\nDesigned and developed by Govind",13,palette.muted);aboutText.setGravity(Gravity.START);about.addView(aboutText,Ui.margins(this,Ui.MATCH,Ui.WRAP,0,7,0,0));page.addView(about,Ui.margins(this,Ui.MATCH,Ui.WRAP,0,22,0,0));
        scroll.addView(page,centeredScrollParams(720));root.addView(scroll,new LinearLayout.LayoutParams(Ui.MATCH,0,1));safeContentView(root);
    }

    private void updateBiometricStatus(){boolean enabled=SecurityManager.get(this).isBiometricEnabled();biometricStatus.setText(enabled?"Strong-biometric unlock is enabled on this device.":"Optional. Your PIN and recovery phrase continue to work independently.");biometric.setText(enabled?"Disable biometric unlock":"Enable strong biometric");}

    private void toggleBiometric(){
        SecurityManager security=SecurityManager.get(this);if(security.isBiometricEnabled()){biometric.setEnabled(false);task=SecureWork.submit(()->{security.disableBiometric();return Boolean.TRUE;},(ok,error)->{biometric.setEnabled(true);if(error!=null){SettingsActivity.this.error(error);return;}updateBiometricStatus();message("Biometric unlock disabled");});return;}
        BiometricManager manager=getSystemService(BiometricManager.class);if(manager==null||manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)!=BiometricManager.BIOMETRIC_SUCCESS){message("Enroll a strong biometric in Android settings first");return;}
        biometric.setEnabled(false);biometricStatus.setText("Preparing an auth-bound device key…");
        task=SecureWork.submit(()->security.beginBiometricEnrollmentCipher(),(cipher,error)->{if(error!=null){biometric.setEnabled(true);SettingsActivity.this.error(error);updateBiometricStatus();return;}showEnrollmentPrompt(cipher);});
    }

    private void showEnrollmentPrompt(Cipher cipher){
        BiometricPrompt prompt=new BiometricPrompt.Builder(this).setTitle("Enable biometric unlock").setSubtitle("Confirm with a strong biometric")
                .setNegativeButton("Cancel",getMainExecutor(),(dialog,which)->{biometric.setEnabled(true);updateBiometricStatus();}).build();
        prompt.authenticate(new BiometricPrompt.CryptoObject(cipher),null,getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){Cipher authenticated=result.getCryptoObject()==null?null:result.getCryptoObject().getCipher();if(authenticated==null){biometric.setEnabled(true);message("Secure biometric cipher was unavailable");return;}task=SecureWork.submit(()->{SecurityManager.get(SettingsActivity.this).finishBiometricEnrollment(authenticated);return Boolean.TRUE;},(ok,error)->{biometric.setEnabled(true);if(error!=null){SettingsActivity.this.error(error);return;}updateBiometricStatus();message("Biometric unlock enabled");});}
            @Override public void onAuthenticationError(int code,CharSequence message){biometric.setEnabled(true);updateBiometricStatus();if(code!=BiometricPrompt.BIOMETRIC_ERROR_CANCELED&&code!=BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED)SettingsActivity.this.message(message.toString());}
            @Override public void onAuthenticationFailed(){biometricStatus.setText("Biometric not recognized. Try again.");}
        });
    }

    private void changePin(){
        String first=newPin.getText().toString(),second=confirmPin.getText().toString();if(!TextUtils.equals(first,second)){message("New PIN entries do not match");return;}
        char[] current=currentPin.getText().toString().toCharArray(),next=first.toCharArray();changePin.setEnabled(false);changePin.setText("Re-wrapping vault key…");
        task=SecureWork.submit(()->{SecurityManager.get(this).changePin(current,next);return Boolean.TRUE;},(ok,error)->{Arrays.fill(current,'\0');Arrays.fill(next,'\0');currentPin.setText("");newPin.setText("");confirmPin.setText("");changePin.setEnabled(true);changePin.setText("Change PIN securely");if(error!=null){SettingsActivity.this.error(error);return;}message("PIN changed securely");});
    }

    @Override protected void clearSensitiveUi(){if(task!=null)task.cancel();if(currentPin!=null)currentPin.setText("");if(newPin!=null)newPin.setText("");if(confirmPin!=null)confirmPin.setText("");}
    @Override protected void onDestroy(){if(task!=null)task.cancel();super.onDestroy();}
}
