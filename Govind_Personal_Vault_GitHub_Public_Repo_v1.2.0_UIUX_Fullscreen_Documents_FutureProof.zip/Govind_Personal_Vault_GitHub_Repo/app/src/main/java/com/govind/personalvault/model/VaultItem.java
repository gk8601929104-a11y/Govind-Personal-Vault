package com.govind.personalvault.model;

public final class VaultItem {
    public static final String PASSWORD = "password";
    public static final String NOTE = "note";

    public String id = "";
    public String kind = PASSWORD;
    public String title = "";
    public String username = "";
    public String secret = "";
    public String url = "";
    public String notes = "";
    public long createdAt;
    public long updatedAt;

    public VaultItem copy() {
        VaultItem copy = new VaultItem();
        copy.id = safe(id); copy.kind = safe(kind); copy.title = safe(title); copy.username = safe(username);
        copy.secret = safe(secret); copy.url = safe(url); copy.notes = safe(notes);
        copy.createdAt = createdAt; copy.updatedAt = updatedAt;
        return copy;
    }

    public static boolean validKind(String value) { return PASSWORD.equals(value) || NOTE.equals(value); }
    private static String safe(String value) { return value == null ? "" : value; }
}
