package com.govind.personalvault.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

public final class Ui {
    public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    public static final class Palette {
        public final int bg = Color.rgb(5,7,10);
        public final int surface = Color.rgb(17,21,27);
        public final int raised = Color.rgb(27,33,41);
        public final int text = Color.rgb(245,248,250);
        public final int muted = Color.rgb(157,168,181);
        public final int accent = Color.rgb(125,226,184);
        public final int accentText = Color.rgb(5,38,27);
        public final int danger = Color.rgb(255,112,122);
        public final int warning = Color.rgb(247,190,91);
        public final int line = Color.rgb(47,56,67);
    }

    private static final Palette PALETTE = new Palette();
    private Ui() {}
    public static Palette colors() { return PALETTE; }
    public static int dp(Context context, float value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }

    public static LinearLayout vertical(Context context) { LinearLayout view = new LinearLayout(context); view.setOrientation(LinearLayout.VERTICAL); return view; }
    public static LinearLayout horizontal(Context context) { LinearLayout view = new LinearLayout(context); view.setOrientation(LinearLayout.HORIZONTAL); view.setGravity(Gravity.CENTER_VERTICAL); return view; }

    public static TextView text(Context context, String value, float size, int color) {
        TextView view = new TextView(context); view.setText(value); view.setTextSize(size); view.setTextColor(color); view.setFontFeatureSettings("kern"); return view;
    }

    public static TextView title(Context context, String value) {
        TextView view = text(context, value, 25, PALETTE.text); view.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return view;
    }

    public static TextView heading(Context context, String value) {
        TextView view = text(context, value, 19, PALETTE.text); view.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return view;
    }

    public static TextView label(Context context, String value) {
        TextView view = text(context, value, 13, PALETTE.muted); view.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return view;
    }

    public static EditText edit(Context context, String hint, int maxLength) {
        EditText edit = baseEdit(context, hint, maxLength);
        edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        return edit;
    }

    public static EditText username(Context context, String hint, int maxLength) {
        EditText edit = baseEdit(context, hint, maxLength);
        edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return edit;
    }

    public static EditText secret(Context context, String hint, int maxLength) {
        EditText edit = baseEdit(context, hint, maxLength);
        edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return edit;
    }

    public static EditText pin(Context context, String hint) {
        EditText edit = baseEdit(context, hint, 12);
        edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        edit.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        edit.setTextSize(20);
        edit.setLetterSpacing(0.18f);
        return edit;
    }

    public static EditText multiLine(Context context, String hint, int maxLength, int minLines) {
        EditText edit = baseEdit(context, hint, maxLength);
        edit.setSingleLine(false); edit.setMinLines(minLines); edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(MATCH, WRAP); edit.setLayoutParams(params);
        edit.setPadding(dp(context,16),dp(context,14),dp(context,16),dp(context,14));
        return edit;
    }

    private static EditText baseEdit(Context context, String hint, int maxLength) {
        EditText edit = new EditText(context);
        edit.setHint(hint); edit.setHintTextColor(PALETTE.muted); edit.setTextColor(PALETTE.text); edit.setTextSize(16);
        edit.setPadding(dp(context,16),dp(context,2),dp(context,16),dp(context,2));
        edit.setBackground(roundRect(context,PALETTE.raised,14,1,withAlpha(PALETTE.line,160)));
        edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        edit.setLayoutParams(new LinearLayout.LayoutParams(MATCH,dp(context,56)));
        edit.setSaveEnabled(false);
        edit.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        return edit;
    }

    public static Button primary(Context context, String text) { return button(context,text,PALETTE.accent,PALETTE.accentText,true); }
    public static Button secondary(Context context, String text) { return button(context,text,PALETTE.raised,PALETTE.text,false); }
    public static Button danger(Context context, String text) { return button(context,text,withAlpha(PALETTE.danger,24),PALETTE.danger,true); }

    public static Button button(Context context, String text, int fill, int textColor, boolean bold) {
        Button button = new Button(context); button.setText(text); button.setTextColor(textColor); button.setTextSize(14); button.setAllCaps(false);
        button.setGravity(Gravity.CENTER); button.setPadding(dp(context,12),0,dp(context,12),0); if (bold) button.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        GradientDrawable base = roundRect(context,fill,14,0,0);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(textColor,40)),base,null));
        button.setMinHeight(0); button.setMinimumHeight(0); button.setLayoutParams(new LinearLayout.LayoutParams(MATCH,dp(context,52))); return button;
    }

    public static LinearLayout card(Context context) {
        LinearLayout card = vertical(context); card.setPadding(dp(context,18),dp(context,17),dp(context,18),dp(context,17));
        card.setBackground(roundRect(context,PALETTE.surface,20,1,PALETTE.line)); return card;
    }

    public static TextView badge(Context context, String text, int color) {
        TextView badge = Ui.text(context,text,12,color); badge.setTypeface(Typeface.DEFAULT,Typeface.BOLD); badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(context,10),dp(context,6),dp(context,10),dp(context,6));
        badge.setBackground(roundRect(context,withAlpha(color,24),99,1,withAlpha(color,80))); return badge;
    }

    public static Space space(Context context, int height) { Space space = new Space(context); space.setLayoutParams(new LinearLayout.LayoutParams(1,dp(context,height))); return space; }
    public static LinearLayout.LayoutParams margins(Context context, int width, int height, int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width,height); p.setMargins(dp(context,l),dp(context,t),dp(context,r),dp(context,b)); return p; }
    public static GradientDrawable roundRect(Context context, int color, float radius, float stroke, int strokeColor) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(context,radius)); if(stroke>0)d.setStroke(dp(context,stroke),strokeColor); return d; }
    public static int withAlpha(int color, int alpha) { return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)); }
}
