#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TEST_DIR="$PROJECT_DIR/build/tests"
rm -rf "$TEST_DIR"
mkdir -p "$TEST_DIR/classes"

javac --release 8 -d "$TEST_DIR/classes" \
  "$PROJECT_DIR/app/src/main/java/com/govind/personalvault/security/CryptoBox.java" \
  "$PROJECT_DIR/app/src/main/java/com/govind/personalvault/security/Bip39.java" \
  "$PROJECT_DIR/app/src/test/java/com/govind/personalvault/security/SecurityCoreTest.java"
java -cp "$TEST_DIR/classes" com.govind.personalvault.security.SecurityCoreTest
