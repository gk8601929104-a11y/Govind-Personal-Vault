#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=version_config.sh
source "$SCRIPT_DIR/version_config.sh"

MANIFEST="$PROJECT_DIR/app/src/main/AndroidManifest.xml"
JAVA_DIR="$PROJECT_DIR/app/src/main/java"

grep -q "android:minSdkVersion=\"$MIN_SDK\"" "$MANIFEST"
grep -q "android:targetSdkVersion=\"$TARGET_SDK\"" "$MANIFEST"
grep -q 'android:allowBackup="false"' "$MANIFEST"
grep -q 'android:usesCleartextTraffic="false"' "$MANIFEST"
grep -q 'android:dataExtractionRules="@xml/data_extraction_rules"' "$MANIFEST"
grep -q 'android.permission.USE_BIOMETRIC' "$MANIFEST"
if grep -q 'android.permission.INTERNET' "$MANIFEST"; then echo "FAIL: Internet permission" >&2; exit 1; fi

grep -q 'FLAG_SECURE' "$JAVA_DIR/com/govind/personalvault/BaseActivity.java"
grep -q 'AES/GCM/NoPadding' "$JAVA_DIR/com/govind/personalvault/security/CryptoBox.java"
grep -q 'PBKDF2WithHmacSHA256' "$JAVA_DIR/com/govind/personalvault/security/SecurityManager.java"
grep -q 'AUTH_BIOMETRIC_STRONG' "$JAVA_DIR/com/govind/personalvault/security/SecurityManager.java"
grep -q 'BiometricPrompt.CryptoObject' "$JAVA_DIR/com/govind/personalvault/LockActivity.java"
grep -q 'newSingleThreadExecutor' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
grep -q 'title_blob TEXT NOT NULL' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
grep -q 'secret_blob TEXT NOT NULL' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
if rg -n 'onSaveInstanceState' "$JAVA_DIR" >/dev/null; then echo "FAIL: sensitive state must not use Bundles" >&2; exit 1; fi
if rg -n 'com\.govind\.smartcalc|govind_smart_calculator' "$PROJECT_DIR/app" >/dev/null; then echo "FAIL: calculator identity leaked into vault" >&2; exit 1; fi

db_calls="$(rg -l 'getWritableDatabase|getReadableDatabase|rawQuery\(' "$JAVA_DIR" || true)"
expected="$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
if [[ "$db_calls" != "$expected" ]]; then echo "FAIL: database access escaped VaultDb" >&2; printf '%s\n' "$db_calls" >&2; exit 1; fi

permission_count="$(rg -c '<uses-permission ' "$MANIFEST")"
if [[ "$permission_count" != "1" ]]; then echo "FAIL: unexpected manifest permission count" >&2; exit 1; fi

printf 'PASS: source security contract for SDK %s/%s, version %s (%s)\n' "$MIN_SDK" "$TARGET_SDK" "$VERSION_NAME" "$VERSION_CODE"
