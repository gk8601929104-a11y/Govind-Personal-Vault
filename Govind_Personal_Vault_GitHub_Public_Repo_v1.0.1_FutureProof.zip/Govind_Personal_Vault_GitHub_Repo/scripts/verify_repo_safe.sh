#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name '*.p12' -o -name '*.pfx' \) -print -quit | grep -q .; then
  echo "ERROR: signing material exists in the repository." >&2
  exit 1
fi

# Guard against accidentally recommitting the original local signing password.
if grep -RIn --exclude-dir=.git --exclude='verify_repo_safe.sh' 'govind-personal-vault-local' .; then
  echo "ERROR: a signing password appears in the repository." >&2
  exit 1
fi

echo "Repository safety check passed: no signing key or known signing password is committed."
