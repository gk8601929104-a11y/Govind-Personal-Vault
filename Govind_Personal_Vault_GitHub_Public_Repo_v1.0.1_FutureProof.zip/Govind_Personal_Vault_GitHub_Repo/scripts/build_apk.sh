#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=version_config.sh
source "$SCRIPT_DIR/version_config.sh"

BUILD_DIR="$PROJECT_DIR/build/apk"
DIST_DIR="$PROJECT_DIR/dist"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
JDK_DIR="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")}" 

: "${SIGNING_KEYSTORE:?SIGNING_KEYSTORE is required}"
: "${SIGNING_STORE_PASSWORD:?SIGNING_STORE_PASSWORD is required}"
: "${SIGNING_KEY_ALIAS:?SIGNING_KEY_ALIAS is required}"
: "${SIGNING_KEY_PASSWORD:?SIGNING_KEY_PASSWORD is required}"

if [[ -z "$SDK_DIR" ]]; then
  echo "Set ANDROID_SDK_ROOT or ANDROID_HOME to your Android SDK directory." >&2
  exit 1
fi
if [[ ! -f "$SIGNING_KEYSTORE" ]]; then
  echo "Signing keystore file was not found." >&2
  exit 1
fi

ANDROID_JAR="$SDK_DIR/platforms/android-$COMPILE_SDK/android.jar"
BUILD_TOOLS_DIR="$SDK_DIR/build-tools/$BUILD_TOOLS_VERSION"
AAPT2="$BUILD_TOOLS_DIR/aapt2"
D8="$BUILD_TOOLS_DIR/d8"
ZIPALIGN="$BUILD_TOOLS_DIR/zipalign"
APKSIGNER="$BUILD_TOOLS_DIR/apksigner"

for required in "$ANDROID_JAR" "$AAPT2" "$D8" "$ZIPALIGN" "$APKSIGNER"; do
  if [[ ! -f "$required" ]]; then
    echo "Required Android SDK file is missing: $required" >&2
    exit 1
  fi
done

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/compiled" "$BUILD_DIR/generated" "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$DIST_DIR"
rm -f "$DIST_DIR"/*.apk "$DIST_DIR"/*.apk.idsig

"$AAPT2" compile --dir "$PROJECT_DIR/app/src/main/res" -o "$BUILD_DIR/compiled/resources.zip"
"$AAPT2" link \
  -o "$BUILD_DIR/resources-unsigned.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$PROJECT_DIR/app/src/main/AndroidManifest.xml" \
  --java "$BUILD_DIR/generated" \
  --min-sdk-version "$MIN_SDK" \
  --target-sdk-version "$TARGET_SDK" \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  -A "$PROJECT_DIR/app/src/main/assets" \
  -R "$BUILD_DIR/compiled/resources.zip" \
  --auto-add-overlay

find "$PROJECT_DIR/app/src/main/java" "$BUILD_DIR/generated" -name '*.java' -type f | sort > "$BUILD_DIR/sources.list"
javac --release 8 -Xlint:all -classpath "$ANDROID_JAR" -d "$BUILD_DIR/classes" @"$BUILD_DIR/sources.list"
jar cf "$BUILD_DIR/classes.jar" -C "$BUILD_DIR/classes" .
"$D8" --lib "$ANDROID_JAR" --lib "$JDK_DIR" --min-api "$MIN_SDK" --output "$BUILD_DIR/dex" "$BUILD_DIR/classes.jar"

cp "$BUILD_DIR/resources-unsigned.apk" "$BUILD_DIR/with-dex-unaligned.apk"
(
  cd "$BUILD_DIR/dex"
  zip -q -j "$BUILD_DIR/with-dex-unaligned.apk" classes.dex
)
"$ZIPALIGN" -f 4 "$BUILD_DIR/with-dex-unaligned.apk" "$BUILD_DIR/aligned.apk"

SIGNED_APK="$BUILD_DIR/signed.apk"
"$APKSIGNER" sign \
  --ks "$SIGNING_KEYSTORE" \
  --ks-key-alias "$SIGNING_KEY_ALIAS" \
  --ks-pass "env:SIGNING_STORE_PASSWORD" \
  --key-pass "env:SIGNING_KEY_PASSWORD" \
  --out "$SIGNED_APK" \
  "$BUILD_DIR/aligned.apk"

"$APKSIGNER" verify --verbose --print-certs "$SIGNED_APK"
cp "$SIGNED_APK" "$OUTPUT_APK"
if [[ -f "$SIGNED_APK.idsig" ]]; then
  cp "$SIGNED_APK.idsig" "$OUTPUT_APK.idsig"
fi
"$APKSIGNER" verify --verbose "$OUTPUT_APK"
printf 'Built %s (versionCode=%s, versionName=%s)\n' "$OUTPUT_APK" "$VERSION_CODE" "$VERSION_NAME"
