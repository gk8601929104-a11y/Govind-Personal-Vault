# Tablet-only build guide

This repository is intentionally safe to make public. It does not contain the signing keystore, signing passwords, PINs, recovery phrases, or any vault database.

## One-time setup

1. Create a free GitHub account.
2. Create a new PUBLIC repository named `govind-personal-vault`.
3. Upload the contents of this folder, not the outer ZIP and never the PRIVATE signing kit.
4. In the repository, open Settings > Secrets and variables > Actions.
5. Add these four repository secrets from the separate private signing kit:
   - `SIGNING_KEYSTORE_BASE64`
   - `SIGNING_STORE_PASSWORD`
   - `SIGNING_KEY_ALIAS`
   - `SIGNING_KEY_PASSWORD`

## Build APK

1. Open the repository's Actions tab.
2. Open `Build signed APK`.
3. Tap `Run workflow`, then tap the green `Run workflow` button.
4. Open the completed green run.
5. Under Artifacts, download `Govind-Personal-Vault-v1.0.1`.
6. Extract the downloaded ZIP and install the APK.

The workflow runs only when manually started. The APK artifact is retained for one day to reduce storage use.
