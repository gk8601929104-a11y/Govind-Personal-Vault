# Phase 1 Security Audit

## Implemented controls

- **No network surface:** the manifest does not request Internet access and cleartext traffic is disabled.
- **No platform backup:** cloud backup and device-transfer extraction rules exclude every app data domain.
- **Authenticated encryption:** sensitive database fields and drafts use AES-256-GCM with fresh random IVs and contextual AAD.
- **Key separation:** database data is encrypted by a random VMK. PIN, recovery, and biometric paths wrap that key independently.
- **PIN resistance:** PBKDF2-HMAC-SHA256 plus a non-exportable Android Keystore HMAC pepper and persisted exponential lockout.
- **Biometric binding:** biometric unlock uses `BiometricPrompt.CryptoObject` and a strong-biometric auth-per-use Keystore AES key.
- **Recovery:** 128-bit entropy plus BIP39 checksum creates 12 words. The normalized phrase derives a recovery wrapping key; the phrase itself is never persisted.
- **Database threading:** all SQLite and record encryption/decryption work runs on one background executor; UI callbacks return on the main looper.
- **Lifecycle:** the in-memory VMK is wiped when the application has no started activity, except during configuration change.
- **Display protection:** each activity applies `FLAG_SECURE` before rendering.
- **State size:** plaintext editor fields are not written to activity bundles; bounded encrypted drafts use private preferences.

## Deliberate metadata exposure

SQLite row type, row identifier, and timestamps are stored in plaintext to support indexing. Titles, usernames, passwords, URLs, and note bodies are encrypted. A local attacker who can extract the sandbox may infer item counts and update times but not sensitive field contents without the VMK.

## Not claimed

- Protection after the user unlocks a rooted or malware-controlled device.
- Protection from physical observation or an external camera.
- Independent third-party cryptographic certification.
- Recovery after app uninstall/data clear, because Android removes the private database and Keystore material.

## Phase 2 boundary

Media import is intentionally absent from Phase 1. A future implementation must use chunked authenticated encryption, unique per-file keys, encrypted thumbnails, atomic temporary files, internal private storage, and bounded buffers. It must never load entire videos into memory.
