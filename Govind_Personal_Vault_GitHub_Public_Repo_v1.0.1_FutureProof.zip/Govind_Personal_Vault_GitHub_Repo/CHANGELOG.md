# Changelog

## 1.0.1

- Fixed startup database initialization on devices that classify `PRAGMA secure_delete=ON` as a query.
- Debounced vault search by 300 ms and cancelled pending searches when the activity leaves the foreground.
- Added an embedded search clear control.
- Added circular, deterministic entry avatars.
- Replaced plain empty text with an icon, explanatory copy, and a direct add action.
- Added smooth open/close activity animations.
- New entries now focus the title field and open the keyboard automatically.
- Simplified editor `onStop()` draft persistence without changing encrypted-draft behavior.

The package name, database name, schema version, signing keystore, and encryption design are unchanged so this build can update version 1.0.0 without deleting existing vault data.
