package com.govind.personalvault.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.govind.personalvault.model.VaultItem;
import com.govind.personalvault.security.SecurityManager;
import com.govind.personalvault.security.VaultSession;

import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/** Serialized asynchronous SQLite access. Sensitive columns contain only AES-GCM envelopes. */
public final class VaultDb extends SQLiteOpenHelper {
    private static final String TAG = "VaultDb";
    private static final String DB_NAME = "govind_personal_vault.db";
    private static final int DB_VERSION = 1;
    private static volatile VaultDb instance;

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "vault-database");
        thread.setPriority(Thread.NORM_PRIORITY - 1);
        thread.setUncaughtExceptionHandler((failed, error) -> Log.e(TAG, "Database worker failed", error));
        return thread;
    });
    private final Handler main = new Handler(Looper.getMainLooper());

    public interface Callback<T> { void onComplete(T result, Exception error); }

    public static final class Counts {
        public final int passwords;
        public final int notes;
        Counts(int passwords, int notes) { this.passwords = passwords; this.notes = notes; }
    }

    public static final class Task {
        private final AtomicBoolean cancelled = new AtomicBoolean();
        private Future<?> future;
        private synchronized void attach(Future<?> value) { future = value; if (cancelled.get()) value.cancel(false); }
        public synchronized void cancel() { cancelled.set(true); if (future != null) future.cancel(false); }
        private boolean isCancelled() { return cancelled.get(); }
    }

    public static VaultDb get(Context context) {
        VaultDb value = instance;
        if (value == null) {
            synchronized (VaultDb.class) {
                value = instance;
                if (value == null) instance = value = new VaultDb(context.getApplicationContext());
            }
        }
        return value;
    }

    private VaultDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);

        // PRAGMA secure_delete returns a result row on Android's SQLite build. Executing it
        // through execSQL() is rejected as a query on some devices, which caused the launcher
        // toast: "Queries can be performed using SQLiteDatabase query or rawQuery methods only."
        Cursor pragma = db.rawQuery("PRAGMA secure_delete=ON", null);
        try {
            if (pragma.moveToFirst() && pragma.getInt(0) == 0) {
                Log.w(TAG, "SQLite secure_delete could not be enabled");
            }
        } finally {
            pragma.close();
        }
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE vault_items (" +
                "_id TEXT PRIMARY KEY," +
                "kind TEXT NOT NULL CHECK(kind IN ('password','note'))," +
                "title_blob TEXT NOT NULL," +
                "username_blob TEXT NOT NULL," +
                "secret_blob TEXT NOT NULL," +
                "url_blob TEXT NOT NULL," +
                "notes_blob TEXT NOT NULL," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX vault_kind_updated_idx ON vault_items(kind, updated_at DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 has no migration. Future versions must use additive, explicit migrations.
    }

    public Task saveAsync(VaultItem source, Callback<String> callback) {
        VaultItem snapshot = source == null ? new VaultItem() : source.copy();
        return submit(() -> saveBlocking(snapshot), callback);
    }

    public Task getAsync(String id, Callback<VaultItem> callback) {
        final String requested = safeId(id);
        return submit(() -> getBlocking(requested), callback);
    }

    public Task listAsync(String kind, String search, int limit, Callback<List<VaultItem>> callback) {
        final String requestedKind = VaultItem.validKind(kind) ? kind : VaultItem.PASSWORD;
        final String query = search == null ? "" : search.trim().toLowerCase(Locale.ROOT);
        final int safeLimit = Math.max(1, Math.min(1000, limit));
        return submit(() -> listBlocking(requestedKind, query, safeLimit), callback);
    }

    public Task deleteAsync(String id, Callback<Boolean> callback) {
        final String requested = safeId(id);
        return submit(() -> getWritableDatabase().delete("vault_items", "_id=?", new String[]{requested}) > 0, callback);
    }

    public Task countsAsync(Callback<Counts> callback) {
        return submit(() -> {
            int passwords = 0, notes = 0;
            Cursor cursor = getReadableDatabase().rawQuery("SELECT kind, COUNT(*) FROM vault_items GROUP BY kind", null);
            try {
                while (cursor.moveToNext()) {
                    if (VaultItem.PASSWORD.equals(cursor.getString(0))) passwords = cursor.getInt(1);
                    else if (VaultItem.NOTE.equals(cursor.getString(0))) notes = cursor.getInt(1);
                }
            } finally { cursor.close(); }
            return new Counts(passwords, notes);
        }, callback);
    }

    private String saveBlocking(VaultItem item) throws Exception {
        if (!VaultSession.isUnlocked()) throw new GeneralSecurityException("Vault is locked");
        if (!VaultItem.validKind(item.kind)) throw new GeneralSecurityException("Invalid vault item type");
        if (item.title.trim().isEmpty()) throw new GeneralSecurityException("Title is required");
        String id = item.id == null || item.id.isEmpty() ? UUID.randomUUID().toString() : safeId(item.id);
        long now = System.currentTimeMillis();
        long created = item.createdAt > 0 ? item.createdAt : existingCreatedAt(id, now);
        SecurityManager security = SecurityManager.get(context);
        ContentValues values = new ContentValues();
        values.put("_id", id);
        values.put("kind", item.kind);
        values.put("title_blob", security.encryptField(id, "title", item.title));
        values.put("username_blob", security.encryptField(id, "username", item.username));
        values.put("secret_blob", security.encryptField(id, "secret", item.secret));
        values.put("url_blob", security.encryptField(id, "url", item.url));
        values.put("notes_blob", security.encryptField(id, "notes", item.notes));
        values.put("created_at", created);
        values.put("updated_at", now);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long row = db.insertWithOnConflict("vault_items", null, values, SQLiteDatabase.CONFLICT_REPLACE);
            if (row < 0) throw new GeneralSecurityException("Vault item could not be saved");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return id;
    }

    private VaultItem getBlocking(String id) throws Exception {
        Cursor cursor = getReadableDatabase().query("vault_items", null, "_id=?", new String[]{id}, null, null, null, "1");
        try { return cursor.moveToFirst() ? decode(cursor) : null; }
        finally { cursor.close(); }
    }

    private List<VaultItem> listBlocking(String kind, String query, int limit) throws Exception {
        ArrayList<VaultItem> result = new ArrayList<VaultItem>();
        Cursor cursor = getReadableDatabase().query("vault_items", null, "kind=?", new String[]{kind}, null, null, "updated_at DESC", String.valueOf(limit));
        try {
            while (cursor.moveToNext()) {
                VaultItem item = decode(cursor);
                if (query.isEmpty() || matches(item, query)) result.add(item);
            }
        } finally { cursor.close(); }
        return result;
    }

    private VaultItem decode(Cursor cursor) throws Exception {
        String id = cursor.getString(cursor.getColumnIndexOrThrow("_id"));
        SecurityManager security = SecurityManager.get(context);
        VaultItem item = new VaultItem();
        item.id = id;
        item.kind = cursor.getString(cursor.getColumnIndexOrThrow("kind"));
        item.title = security.decryptField(id, "title", cursor.getString(cursor.getColumnIndexOrThrow("title_blob")));
        item.username = security.decryptField(id, "username", cursor.getString(cursor.getColumnIndexOrThrow("username_blob")));
        item.secret = security.decryptField(id, "secret", cursor.getString(cursor.getColumnIndexOrThrow("secret_blob")));
        item.url = security.decryptField(id, "url", cursor.getString(cursor.getColumnIndexOrThrow("url_blob")));
        item.notes = security.decryptField(id, "notes", cursor.getString(cursor.getColumnIndexOrThrow("notes_blob")));
        item.createdAt = cursor.getLong(cursor.getColumnIndexOrThrow("created_at"));
        item.updatedAt = cursor.getLong(cursor.getColumnIndexOrThrow("updated_at"));
        return item;
    }

    private long existingCreatedAt(String id, long fallback) {
        Cursor cursor = getReadableDatabase().query("vault_items", new String[]{"created_at"}, "_id=?", new String[]{id}, null, null, null, "1");
        try { return cursor.moveToFirst() ? cursor.getLong(0) : fallback; }
        finally { cursor.close(); }
    }

    private boolean matches(VaultItem item, String query) {
        return item.title.toLowerCase(Locale.ROOT).contains(query)
                || item.username.toLowerCase(Locale.ROOT).contains(query)
                || item.url.toLowerCase(Locale.ROOT).contains(query)
                || item.notes.toLowerCase(Locale.ROOT).contains(query);
    }

    private String safeId(String id) {
        if (id == null || id.length() > 64 || !id.matches("[A-Za-z0-9._-]+")) throw new IllegalArgumentException("Invalid item identifier");
        return id;
    }

    private <T> Task submit(Callable<T> operation, Callback<T> callback) {
        Task task = new Task();
        task.attach(executor.submit(() -> {
            if (task.isCancelled()) return;
            T result = null;
            Exception error = null;
            try { result = operation.call(); }
            catch (Exception failure) { error = failure; }
            if (task.isCancelled()) return;
            T delivered = result;
            Exception failure = error;
            main.post(() -> {
                if (task.isCancelled()) return;
                Exception visibleFailure = failure;
                T visibleResult = delivered;
                if (!VaultSession.isUnlocked() && visibleFailure == null) { visibleFailure = new GeneralSecurityException("Vault was locked"); visibleResult=null; }
                try { if (callback != null) callback.onComplete(visibleResult, visibleFailure); }
                catch (RuntimeException callbackError) { Log.e(TAG, "Database callback failed", callbackError); }
            });
        }));
        return task;
    }
}
