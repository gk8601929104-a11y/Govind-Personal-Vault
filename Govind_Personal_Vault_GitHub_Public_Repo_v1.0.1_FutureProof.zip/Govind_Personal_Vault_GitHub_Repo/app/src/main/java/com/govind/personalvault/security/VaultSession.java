package com.govind.personalvault.security;

import java.security.GeneralSecurityException;
import java.util.Arrays;

/** Process-memory-only holder for the unlocked vault master key. */
public final class VaultSession {
    private static byte[] key;

    private VaultSession() {}

    public static synchronized void unlock(byte[] masterKey) throws GeneralSecurityException {
        if (masterKey == null || masterKey.length != CryptoBox.KEY_BYTES) throw new GeneralSecurityException("Invalid vault key");
        lock();
        key = Arrays.copyOf(masterKey, masterKey.length);
    }

    public static synchronized boolean isUnlocked() { return key != null; }

    public static synchronized byte[] requireKeyCopy() throws GeneralSecurityException {
        if (key == null) throw new GeneralSecurityException("Vault is locked");
        return Arrays.copyOf(key, key.length);
    }

    public static synchronized void lock() {
        if (key != null) Arrays.fill(key, (byte) 0);
        key = null;
    }
}
