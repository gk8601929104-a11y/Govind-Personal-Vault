package com.govind.personalvault;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.govind.personalvault.data.VaultDb;
import com.govind.personalvault.model.VaultItem;
import com.govind.personalvault.security.VaultSession;
import com.govind.personalvault.ui.Ui;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class VaultActivity extends BaseActivity {
    private static final int DELETE_REQUEST = 73;
    private static final long SEARCH_DEBOUNCE_MS = 300L;

    private boolean active;
    private final Handler searchHandler = new Handler(Looper.getMainLooper());
    private final Runnable pendingSearch = () -> {
        if (active && VaultSession.isUnlocked()) loadItems();
    };

    private String selectedKind = VaultItem.PASSWORD;
    private Button passwordsTab;
    private Button notesTab;
    private Button add;
    private Button emptyAction;
    private TextView passwordCount;
    private TextView noteCount;
    private TextView listTitle;
    private TextView clearSearch;
    private TextView emptyIcon;
    private TextView emptyTitle;
    private TextView emptySubtitle;
    private LinearLayout emptyState;
    private EditText search;
    private ListView list;
    private ItemAdapter adapter;
    private VaultDb.Task listTask;
    private VaultDb.Task countTask;
    private long loadGeneration;
    private boolean suppressSearch;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        active = VaultSession.isUnlocked();
        if (active) {
            loadCounts();
            loadItems();
        }
    }

    @Override protected void onStop() {
        active = false;
        searchHandler.removeCallbacks(pendingSearch);
        super.onStop();
    }

    private void build() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(palette.bg);
        root.addView(topBar(
                "Govind Personal Vault",
                "Offline • private • auto-lock",
                false,
                "Settings",
                v -> startActivity(new Intent(this, SettingsActivity.class))));

        LinearLayout header = Ui.vertical(this);
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 10));

        LinearLayout stats = Ui.card(this);
        LinearLayout statRow = Ui.horizontal(this);
        LinearLayout pStat = statBlock("PASSWORDS");
        passwordCount = (TextView) pStat.getChildAt(1);
        statRow.addView(pStat, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        LinearLayout nStat = statBlock("PRIVATE NOTES");
        noteCount = (TextView) nStat.getChildAt(1);
        statRow.addView(nStat, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        Button lock = Ui.secondary(this, "Lock now");
        lock.setOnClickListener(v -> lockNow());
        statRow.addView(lock, new LinearLayout.LayoutParams(Ui.dp(this, 104), Ui.dp(this, 50)));
        stats.addView(statRow);
        header.addView(stats);

        LinearLayout tabs = Ui.horizontal(this);
        passwordsTab = Ui.secondary(this, "Passwords");
        notesTab = Ui.secondary(this, "Notes");
        passwordsTab.setOnClickListener(v -> select(VaultItem.PASSWORD));
        notesTab.setOnClickListener(v -> select(VaultItem.NOTE));
        tabs.addView(passwordsTab, new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1));
        LinearLayout.LayoutParams noteTabParams = new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1);
        noteTabParams.leftMargin = Ui.dp(this, 8);
        tabs.addView(notesTab, noteTabParams);
        header.addView(tabs, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

        listTitle = Ui.heading(this, "Passwords");
        header.addView(listTitle, Ui.margins(this, Ui.MATCH, Ui.WRAP, 1, 16, 1, 7));
        header.addView(buildSearchBox());
        root.addView(header);

        LinearLayout listLayer = Ui.vertical(this);
        list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(android.R.color.transparent);
        list.setClipToPadding(false);
        list.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), Ui.dp(this, 12));
        adapter = new ItemAdapter();
        list.setAdapter(adapter);
        listLayer.addView(list, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        emptyState = buildEmptyState();
        listLayer.addView(emptyState, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));
        root.addView(listLayer, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        LinearLayout bottom = Ui.horizontal(this);
        bottom.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        bottom.setBackgroundColor(palette.surface);
        add = Ui.primary(this, "Add password");
        add.setOnClickListener(v -> openEditor(null));
        bottom.addView(add, new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 54)));
        root.addView(bottom);

        safeContentView(root);
        updateTabs();
    }

    private View buildSearchBox() {
        LinearLayout box = Ui.horizontal(this);
        box.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        box.setBackground(Ui.roundRect(this, palette.raised, 14, 1, Ui.withAlpha(palette.line, 160)));

        search = Ui.edit(this, "Search unlocked items", 160);
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(Ui.dp(this, 12), Ui.dp(this, 2), Ui.dp(this, 8), Ui.dp(this, 2));
        box.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1));

        clearSearch = Ui.text(this, "×", 28, palette.muted);
        clearSearch.setGravity(Gravity.CENTER);
        clearSearch.setContentDescription("Clear search");
        clearSearch.setClickable(true);
        clearSearch.setFocusable(true);
        clearSearch.setVisibility(View.GONE);
        clearSearch.setBackground(Ui.roundRect(this, palette.surface, 12, 0, 0));
        clearSearch.setOnClickListener(v -> {
            if (search.length() > 0) search.setText("");
        });
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44));
        box.addView(clearSearch, clearParams);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }

            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                clearSearch.setVisibility(value.length() == 0 ? View.GONE : View.VISIBLE);
                if (suppressSearch) return;
                searchHandler.removeCallbacks(pendingSearch);
                searchHandler.postDelayed(pendingSearch, SEARCH_DEBOUNCE_MS);
            }

            @Override public void afterTextChanged(Editable value) { }
        });
        return box;
    }

    private LinearLayout buildEmptyState() {
        LinearLayout state = Ui.vertical(this);
        state.setGravity(Gravity.CENTER);
        state.setPadding(Ui.dp(this, 28), Ui.dp(this, 28), Ui.dp(this, 28), Ui.dp(this, 28));
        state.setVisibility(View.GONE);

        emptyIcon = Ui.text(this, "🔐", 52, palette.muted);
        emptyIcon.setGravity(Gravity.CENTER);
        state.addView(emptyIcon, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        emptyTitle = Ui.heading(this, "No passwords yet");
        emptyTitle.setGravity(Gravity.CENTER);
        state.addView(emptyTitle);

        emptySubtitle = Ui.text(
                this,
                "Add your first password and it will be encrypted before being stored.",
                14,
                palette.muted);
        emptySubtitle.setGravity(Gravity.CENTER);
        emptySubtitle.setLineSpacing(0, 1.18f);
        state.addView(emptySubtitle, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 18));

        emptyAction = Ui.primary(this, "Add your first password");
        emptyAction.setOnClickListener(v -> openEditor(null));
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(
                Math.min(Ui.dp(this, 300), getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 72)),
                Ui.dp(this, 52));
        actionParams.gravity = Gravity.CENTER_HORIZONTAL;
        state.addView(emptyAction, actionParams);
        return state;
    }

    private LinearLayout statBlock(String label) {
        LinearLayout block = Ui.vertical(this);
        TextView name = Ui.text(this, label, 11, palette.muted);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        block.addView(name);
        TextView value = Ui.text(this, "0", 24, palette.accent);
        value.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        block.addView(value);
        return block;
    }

    private void select(String kind) {
        if (kind.equals(selectedKind)) return;
        selectedKind = kind;
        searchHandler.removeCallbacks(pendingSearch);
        suppressSearch = true;
        search.setText("");
        suppressSearch = false;
        clearSearch.setVisibility(View.GONE);
        updateTabs();
        loadItems();
    }

    private void updateTabs() {
        boolean passwords = VaultItem.PASSWORD.equals(selectedKind);
        passwordsTab.setBackground(Ui.roundRect(
                this,
                passwords ? Ui.withAlpha(palette.accent, 30) : palette.raised,
                14,
                1,
                passwords ? Ui.withAlpha(palette.accent, 100) : palette.line));
        notesTab.setBackground(Ui.roundRect(
                this,
                !passwords ? Ui.withAlpha(palette.accent, 30) : palette.raised,
                14,
                1,
                !passwords ? Ui.withAlpha(palette.accent, 100) : palette.line));
        passwordsTab.setTextColor(passwords ? palette.accent : palette.text);
        notesTab.setTextColor(!passwords ? palette.accent : palette.text);
        listTitle.setText(passwords ? "Passwords" : "Private notes");
        add.setText(passwords ? "Add password" : "Add private note");
        emptyIcon.setText(passwords ? "🔐" : "📝");
        emptyTitle.setText(passwords ? "No passwords yet" : "No private notes yet");
        emptySubtitle.setText(passwords
                ? "Add your first password and it will be encrypted before being stored."
                : "Add your first private note and keep it encrypted on this device.");
        emptyAction.setText(passwords ? "Add your first password" : "Add your first private note");
    }

    private void loadCounts() {
        if (countTask != null) countTask.cancel();
        countTask = VaultDb.get(this).countsAsync((counts, error) -> {
            if (!active) return;
            if (error != null) {
                if (VaultSession.isUnlocked()) VaultActivity.this.error(error);
                return;
            }
            passwordCount.setText(String.valueOf(counts.passwords));
            noteCount.setText(String.valueOf(counts.notes));
        });
    }

    private void loadItems() {
        if (!active || !VaultSession.isUnlocked()) return;
        if (listTask != null) listTask.cancel();
        long generation = ++loadGeneration;
        String query = search == null ? "" : search.getText().toString();
        listTask = VaultDb.get(this).listAsync(selectedKind, query, 500, (items, error) -> {
            if (!active || generation != loadGeneration) return;
            if (error != null) {
                if (VaultSession.isUnlocked()) VaultActivity.this.error(error);
                return;
            }
            adapter.replace(items);
            boolean isEmpty = items == null || items.isEmpty();
            list.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
            emptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        });
    }

    private void openEditor(VaultItem item) {
        Intent intent = new Intent(this, EntryEditorActivity.class);
        intent.putExtra("kind", selectedKind);
        if (item != null) intent.putExtra("item_id", item.id);
        startActivity(intent);
    }

    private void lockNow() {
        adapter.clear();
        VaultSession.lock();
        Intent lock = new Intent(this, LockActivity.class);
        lock.putExtra("overlay", true);
        startActivity(lock);
    }

    private void askDelete(VaultItem item) {
        Intent intent = new Intent(this, DeleteConfirmActivity.class);
        intent.putExtra("item_id", item.id);
        startActivityForResult(intent, DELETE_REQUEST);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == DELETE_REQUEST && result == RESULT_OK) {
            message("Item deleted");
            loadCounts();
            loadItems();
        }
    }

    @Override protected void clearSensitiveUi() {
        active = false;
        loadGeneration++;
        searchHandler.removeCallbacks(pendingSearch);
        if (listTask != null) listTask.cancel();
        if (countTask != null) countTask.cancel();
        if (adapter != null) adapter.clear();
        if (list != null) list.setVisibility(View.GONE);
        if (emptyState != null) emptyState.setVisibility(View.GONE);
        if (search != null) {
            suppressSearch = true;
            search.setText("");
            suppressSearch = false;
        }
        if (clearSearch != null) clearSearch.setVisibility(View.GONE);
    }

    @Override protected void onDestroy() {
        searchHandler.removeCallbacksAndMessages(null);
        if (listTask != null) listTask.cancel();
        if (countTask != null) countTask.cancel();
        super.onDestroy();
    }

    private final class ItemAdapter extends BaseAdapter {
        private final ArrayList<VaultItem> items = new ArrayList<VaultItem>();

        void replace(List<VaultItem> values) {
            clear();
            if (values != null) {
                for (VaultItem value : values) items.add(value.copy());
            }
            notifyDataSetChanged();
        }

        void clear() {
            for (VaultItem item : items) {
                item.title = "";
                item.username = "";
                item.secret = "";
                item.url = "";
                item.notes = "";
            }
            items.clear();
            notifyDataSetChanged();
        }

        @Override public int getCount() { return items.size(); }
        @Override public VaultItem getItem(int position) { return items.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View reusable, ViewGroup parent) {
            VaultItem item = getItem(position);
            LinearLayout outer = Ui.vertical(VaultActivity.this);
            outer.setPadding(
                    Ui.dp(VaultActivity.this, 4),
                    Ui.dp(VaultActivity.this, 5),
                    Ui.dp(VaultActivity.this, 4),
                    Ui.dp(VaultActivity.this, 5));

            LinearLayout card = Ui.card(VaultActivity.this);
            LinearLayout titleRow = Ui.horizontal(VaultActivity.this);

            int avatarColor = avatarColor(item.title);
            TextView avatar = Ui.text(VaultActivity.this, firstCharacter(item), 19, avatarColor);
            avatar.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            avatar.setGravity(Gravity.CENTER);
            avatar.setContentDescription(VaultItem.PASSWORD.equals(item.kind)
                    ? "Password entry"
                    : "Private note");
            GradientDrawable avatarBackground = new GradientDrawable();
            avatarBackground.setShape(GradientDrawable.OVAL);
            avatarBackground.setColor(Ui.withAlpha(avatarColor, 28));
            avatarBackground.setStroke(Ui.dp(VaultActivity.this, 1), Ui.withAlpha(avatarColor, 100));
            avatar.setBackground(avatarBackground);
            titleRow.addView(avatar, new LinearLayout.LayoutParams(
                    Ui.dp(VaultActivity.this, 50),
                    Ui.dp(VaultActivity.this, 50)));

            LinearLayout labels = Ui.vertical(VaultActivity.this);
            labels.setPadding(Ui.dp(VaultActivity.this, 12), 0, 0, 0);
            TextView title = Ui.heading(VaultActivity.this, item.title);
            title.setMaxLines(1);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            labels.addView(title);
            String secondary = VaultItem.PASSWORD.equals(item.kind)
                    ? firstNonEmpty(item.username, item.url, "Password entry")
                    : preview(item.notes);
            TextView subtitle = Ui.text(VaultActivity.this, secondary, 13, palette.muted);
            subtitle.setMaxLines(2);
            subtitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
            labels.addView(subtitle, Ui.margins(VaultActivity.this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
            titleRow.addView(labels, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
            card.addView(titleRow);

            TextView updated = Ui.text(
                    VaultActivity.this,
                    "Updated " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                            .format(new Date(item.updatedAt)),
                    11,
                    palette.muted);
            card.addView(updated, Ui.margins(VaultActivity.this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

            LinearLayout actions = Ui.horizontal(VaultActivity.this);
            Button edit = Ui.secondary(VaultActivity.this, "Edit");
            edit.setOnClickListener(v -> openEditor(item));
            actions.addView(edit, new LinearLayout.LayoutParams(0, Ui.dp(VaultActivity.this, 46), 1));
            if (VaultItem.PASSWORD.equals(item.kind)) {
                Button copy = Ui.secondary(VaultActivity.this, "Copy password");
                copy.setOnClickListener(v -> copySecret("Vault password", item.secret));
                LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(
                        0, Ui.dp(VaultActivity.this, 46), 1);
                copyParams.leftMargin = Ui.dp(VaultActivity.this, 7);
                actions.addView(copy, copyParams);
            }
            Button delete = Ui.danger(VaultActivity.this, "Delete");
            delete.setOnClickListener(v -> askDelete(item));
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                    0, Ui.dp(VaultActivity.this, 46), 1);
            deleteParams.leftMargin = Ui.dp(VaultActivity.this, 7);
            actions.addView(delete, deleteParams);
            card.addView(actions, Ui.margins(VaultActivity.this, Ui.MATCH, Ui.WRAP, 0, 13, 0, 0));
            outer.addView(card);
            return outer;
        }

        private String firstCharacter(VaultItem item) {
            String value = item.title == null ? "" : item.title.trim();
            if (value.isEmpty()) return VaultItem.PASSWORD.equals(item.kind) ? "P" : "N";
            int codePoint = value.codePointAt(0);
            return new String(Character.toChars(codePoint)).toUpperCase(Locale.getDefault());
        }

        private int avatarColor(String seed) {
            int[] colors = new int[] {
                    palette.accent,
                    palette.warning,
                    palette.danger,
                    Color.rgb(132, 168, 255),
                    Color.rgb(194, 145, 255),
                    Color.rgb(95, 205, 230)
            };
            String value = seed == null ? "" : seed;
            return colors[Math.floorMod(value.hashCode(), colors.length)];
        }

        private String firstNonEmpty(String first, String second, String fallback) {
            if (first != null && !first.isEmpty()) return first;
            if (second != null && !second.isEmpty()) return second;
            return fallback;
        }

        private String preview(String value) {
            if (value == null || value.trim().isEmpty()) return "Private note";
            String clean = value.trim().replaceAll("\\s+", " ");
            return clean.length() > 100 ? clean.substring(0, 100) + "…" : clean;
        }
    }
}
