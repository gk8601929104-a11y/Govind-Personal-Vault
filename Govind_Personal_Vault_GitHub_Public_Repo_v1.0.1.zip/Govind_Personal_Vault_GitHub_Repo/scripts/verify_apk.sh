#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
APK="$PROJECT_DIR/dist/Govind_Personal_Vault_v1.0.1.apk"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"

if [[ -z "$SDK_DIR" || ! -f "$APK" ]]; then
  echo "Build the APK and set ANDROID_SDK_ROOT first." >&2
  exit 1
fi

AAPT2="$(find "$SDK_DIR/build-tools" -name aapt2 -type f | sort -V | tail -1)"
APKSIGNER="$(find "$SDK_DIR/build-tools" -name apksigner -type f | sort -V | tail -1)"
ZIPALIGN="$(find "$SDK_DIR/build-tools" -name zipalign -type f | sort -V | tail -1)"
DEXDUMP="$(find "$SDK_DIR/build-tools" -name dexdump -type f | sort -V | tail -1)"
BADGING="$PROJECT_DIR/build/apk-badging.txt"
MANIFEST_TREE="$PROJECT_DIR/build/apk-manifest.txt"
DEX_CLASSES="$PROJECT_DIR/build/apk-classes.txt"

"$APKSIGNER" verify --verbose "$APK"
"$ZIPALIGN" -c -v 4 "$APK" >/dev/null
unzip -t "$APK" >/dev/null
"$AAPT2" dump badging "$APK" > "$BADGING"
"$AAPT2" dump xmltree "$APK" --file AndroidManifest.xml > "$MANIFEST_TREE"
"$DEXDUMP" -f "$APK" > "$DEX_CLASSES"
grep -q "package: name='com.govind.personalvault'" "$BADGING"
grep -q "minSdkVersion:'31'" "$BADGING"
grep -q "targetSdkVersion:'35'" "$BADGING"
grep -q "versionCode='2' versionName='1.0.1'" "$BADGING"
grep -q "uses-permission: name='android.permission.USE_BIOMETRIC'" "$BADGING"
if grep -q "android.permission.INTERNET" "$BADGING"; then echo "Unexpected INTERNET permission." >&2; exit 1; fi
grep -q 'android:name.*=".MainActivity"' "$MANIFEST_TREE"
grep -q 'android:exported.*=true' "$MANIFEST_TREE"
grep -q 'Class descriptor.*Lcom/govind/personalvault/security/SecurityManager;' "$DEX_CLASSES"
grep -q 'Class descriptor.*Lcom/govind/personalvault/data/VaultDb;' "$DEX_CLASSES"
grep -q 'Class descriptor.*Lcom/govind/personalvault/LockActivity;' "$DEX_CLASSES"
sha256sum "$APK"
echo "PASS: signed standalone Android 12+ vault APK; only biometric permission declared"
