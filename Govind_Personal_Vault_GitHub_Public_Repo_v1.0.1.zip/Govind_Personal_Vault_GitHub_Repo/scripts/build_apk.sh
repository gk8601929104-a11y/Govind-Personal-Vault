#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build/apk"
DIST_DIR="$PROJECT_DIR/dist"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
JDK_DIR="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")}" 

: "${SIGNING_KEYSTORE:?SIGNING_KEYSTORE is required}"
: "${SIGNING_STORE_PASSWORD:?SIGNING_STORE_PASSWORD is required}"
: "${SIGNING_KEY_ALIAS:?SIGNING_KEY_ALIAS is required}"
: "${SIGNING_KEY_PASSWORD:?SIGNING_KEY_PASSWORD is required}"

if [[ -z "$SDK_DIR" ]]; then
  echo "Set ANDROID_SDK_ROOT or ANDROID_HOME to your Android SDK directory." >&2
  exit 1
fi
if [[ ! -f "$SIGNING_KEYSTORE" ]]; then
  echo "Signing keystore file was not found." >&2
  exit 1
fi

ANDROID_JAR="$(find "$SDK_DIR/platforms" -name android.jar -type f | sort -V | tail -1)"
AAPT2="$(find "$SDK_DIR/build-tools" -name aapt2 -type f | sort -V | tail -1)"
D8="$(find "$SDK_DIR/build-tools" -name d8 -type f | sort -V | tail -1)"
ZIPALIGN="$(find "$SDK_DIR/build-tools" -name zipalign -type f | sort -V | tail -1)"
APKSIGNER="$(find "$SDK_DIR/build-tools" -name apksigner -type f | sort -V | tail -1)"

for required in "$ANDROID_JAR" "$AAPT2" "$D8" "$ZIPALIGN" "$APKSIGNER"; do
  if [[ -z "$required" || ! -f "$required" ]]; then
    echo "Android platform/build-tools are incomplete." >&2
    exit 1
  fi
done

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/compiled" "$BUILD_DIR/generated" "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$DIST_DIR"

"$AAPT2" compile --dir "$PROJECT_DIR/app/src/main/res" -o "$BUILD_DIR/compiled/resources.zip"
"$AAPT2" link \
  -o "$BUILD_DIR/resources-unsigned.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$PROJECT_DIR/app/src/main/AndroidManifest.xml" \
  --java "$BUILD_DIR/generated" \
  --min-sdk-version 31 \
  --target-sdk-version 35 \
  --version-code 2 \
  --version-name 1.0.1 \
  -A "$PROJECT_DIR/app/src/main/assets" \
  -R "$BUILD_DIR/compiled/resources.zip" \
  --auto-add-overlay

find "$PROJECT_DIR/app/src/main/java" "$BUILD_DIR/generated" -name '*.java' -type f | sort > "$BUILD_DIR/sources.list"
javac --release 8 -Xlint:all -classpath "$ANDROID_JAR" -d "$BUILD_DIR/classes" @"$BUILD_DIR/sources.list"
jar cf "$BUILD_DIR/classes.jar" -C "$BUILD_DIR/classes" .
"$D8" --lib "$ANDROID_JAR" --lib "$JDK_DIR" --min-api 31 --output "$BUILD_DIR/dex" "$BUILD_DIR/classes.jar"

cp "$BUILD_DIR/resources-unsigned.apk" "$BUILD_DIR/with-dex-unaligned.apk"
(
  cd "$BUILD_DIR/dex"
  zip -q -j "$BUILD_DIR/with-dex-unaligned.apk" classes.dex
)
"$ZIPALIGN" -f 4 "$BUILD_DIR/with-dex-unaligned.apk" "$BUILD_DIR/aligned.apk"

OUTPUT_APK="$DIST_DIR/Govind_Personal_Vault_v1.0.1.apk"
SIGNED_APK="$BUILD_DIR/signed.apk"
"$APKSIGNER" sign \
  --ks "$SIGNING_KEYSTORE" \
  --ks-key-alias "$SIGNING_KEY_ALIAS" \
  --ks-pass "env:SIGNING_STORE_PASSWORD" \
  --key-pass "env:SIGNING_KEY_PASSWORD" \
  --out "$SIGNED_APK" \
  "$BUILD_DIR/aligned.apk"

"$APKSIGNER" verify --verbose --print-certs "$SIGNED_APK"
cp "$SIGNED_APK" "$OUTPUT_APK"
if [[ -f "$SIGNED_APK.idsig" ]]; then cp "$SIGNED_APK.idsig" "$OUTPUT_APK.idsig"; fi
"$APKSIGNER" verify --verbose "$OUTPUT_APK"
echo "Built $OUTPUT_APK"
