# Govind Personal Vault

An offline Android 12+ vault for passwords and private notes. It is a separate application from Govind Smart Calculator: a separate package, database, preferences, runtime keys, APK, and signing identity.

## Phase 1

- Six-to-twelve digit PIN with persisted throttling after repeated failures.
- Optional Android strong-biometric unlock bound to an auth-per-use Android Keystore key.
- A 12-word recovery phrase using the BIP39 English list and checksum format. It is shown once, never stored, and is not a cryptocurrency seed.
- A random 256-bit vault master key wrapped independently by the PIN, recovery phrase, and optional biometric key.
- Per-field AES-256-GCM encryption with a fresh 96-bit nonce and record/field-specific associated data.
- Password and private-note CRUD through a serialized background SQLite worker.
- `FLAG_SECURE`, no Internet permission, cloud/device-transfer backup exclusions, and background auto-lock.
- Encrypted editor drafts; large plaintext is not written to `savedInstanceState`.

## Version 1.0.1 fixes

- Fixed the Android SQLite startup error caused by executing `PRAGMA secure_delete` through `execSQL`.
- Added 300 ms debounced vault search and an in-field clear button.
- Added deterministic circular avatars, richer empty states, and app-wide smooth activity transitions.
- Added automatic title focus and keyboard opening for new entries.
- Removed redundant editor draft-saving logic while preserving encrypted drafts.

## Build

### Free tablet/cloud build

Use the manual GitHub Actions workflow in `.github/workflows/build-apk.yml`. Signing material is supplied only through encrypted repository secrets and is never committed. See `TABLET_GITHUB_BUILD_GUIDE.md`.

### Local build

Set `ANDROID_SDK_ROOT` to an Android SDK containing platform 35 and build-tools 35, set `JAVA_HOME` to JDK 17, export the four `SIGNING_*` variables, then run:

```sh
./scripts/run_tests.sh
./scripts/security_audit.sh
./scripts/build_apk.sh
./scripts/verify_apk.sh
```

The signed APK is written to `dist/Govind_Personal_Vault_v1.0.1.apk`.

## Important security boundaries

This is a carefully designed personal/offline app, not a formally audited commercial password manager. `FLAG_SECURE` reduces accidental screenshots and screen recording but cannot defend against a rooted/compromised phone or an external camera. Losing both the PIN and the recovery phrase makes the vault data unrecoverable. The application never uploads or remotely resets the vault.

Never commit or publicly upload the signing keystore or signing passwords. Keep the separate private signing kit backed up offline. Android app signing and runtime vault encryption are separate systems; runtime encryption keys are generated only on the installed device.

Designed and developed by Govind.
