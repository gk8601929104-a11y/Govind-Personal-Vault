#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=version_config.sh
source "$SCRIPT_DIR/version_config.sh"

: "${PACKAGE_ID:?PACKAGE_ID is required in app/version.properties}"

APK="$OUTPUT_APK"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
BUILD_DIR="$PROJECT_DIR/app/build"
BADGING="$BUILD_DIR/apk-badging.txt"
SIGNATURE_REPORT="$BUILD_DIR/apk-signature.txt"
ALIGN_REPORT="$BUILD_DIR/apk-zipalign.txt"
DEX_CLASSES="$BUILD_DIR/apk-classes.txt"
DEX_TMP="$BUILD_DIR/verified-dex"

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

pass() {
  echo "PASS: $*"
}

require_text() {
  local pattern="$1"
  local file="$2"
  local description="$3"
  if ! grep -Eq "$pattern" "$file"; then
    fail "$description"
  fi
}

[[ -n "$SDK_DIR" ]] || fail "ANDROID_SDK_ROOT or ANDROID_HOME is not set."
[[ -f "$APK" ]] || fail "APK was not found: $APK"

BUILD_TOOLS_DIR="$SDK_DIR/build-tools/$BUILD_TOOLS_VERSION"
AAPT2="$BUILD_TOOLS_DIR/aapt2"
APKSIGNER="$BUILD_TOOLS_DIR/apksigner"
ZIPALIGN="$BUILD_TOOLS_DIR/zipalign"
DEXDUMP="$BUILD_TOOLS_DIR/dexdump"

for required in "$AAPT2" "$APKSIGNER" "$ZIPALIGN" "$DEXDUMP"; do
  [[ -x "$required" ]] || fail "Required Android build tool is missing or not executable: $required"
done

mkdir -p "$BUILD_DIR"
rm -rf "$DEX_TMP"
mkdir -p "$DEX_TMP"
trap 'rm -rf "$DEX_TMP"' EXIT

# apksigner verifies the schemes required for the APK's declared minimum SDK.
# A v3-only result is valid for this app's minSdk 31; v1/v2/v4 do not all need
# to be true at the same time.
if ! "$APKSIGNER" verify \
    --verbose \
    --print-certs \
    --min-sdk-version "$MIN_SDK" \
    "$APK" | tee "$SIGNATURE_REPORT"; then
  fail "APK signature verification failed."
fi
require_text '^Number of signers: 1$' "$SIGNATURE_REPORT" \
  "APK must have exactly one signer."
require_text '^Verified using v(2|3|3[.]1) scheme .*: true$' "$SIGNATURE_REPORT" \
  "APK is not verified by a modern Android signature scheme (v2 or newer)."
pass "APK signature and signer count verified"

if ! "$ZIPALIGN" -c -v 4 "$APK" >"$ALIGN_REPORT" 2>&1; then
  cat "$ALIGN_REPORT" >&2
  fail "APK zip alignment verification failed."
fi
pass "APK zip alignment verified"

if ! unzip -t "$APK" >/dev/null; then
  fail "APK ZIP structure is corrupt."
fi
pass "APK ZIP integrity verified"

if ! "$AAPT2" dump badging "$APK" >"$BADGING"; then
  fail "AAPT2 could not read APK manifest metadata."
fi

# aapt2 dump badging names the minimum SDK field 'sdkVersion', not
# 'minSdkVersion'. Accept the documented badging format and validate each
# value independently so a mismatch produces a clear error.
require_text "package: name='$PACKAGE_ID'" "$BADGING" \
  "Unexpected applicationId; expected $PACKAGE_ID."
require_text "versionCode='$VERSION_CODE'" "$BADGING" \
  "Unexpected versionCode; expected $VERSION_CODE."
require_text "versionName='$VERSION_NAME'" "$BADGING" \
  "Unexpected versionName; expected $VERSION_NAME."
require_text "(^|[[:space:]])sdkVersion:'$MIN_SDK'([[:space:]]|$)" "$BADGING" \
  "Unexpected minSdk; expected $MIN_SDK."
require_text "(^|[[:space:]])targetSdkVersion:'$TARGET_SDK'([[:space:]]|$)" "$BADGING" \
  "Unexpected targetSdk; expected $TARGET_SDK."
require_text "uses-permission[^']*'android[.]permission[.]USE_BIOMETRIC'" "$BADGING" \
  "USE_BIOMETRIC permission is missing from the APK."
require_text "launchable[- ]activity[^']*'${PACKAGE_ID}[.]MainActivity'" "$BADGING" \
  "MainActivity is not the launchable activity."

if grep -Eq "uses-permission[^']*'android[.]permission[.]INTERNET'" "$BADGING"; then
  fail "Unexpected INTERNET permission."
fi
if grep -Eq "uses-permission[^']*'android[.]permission[.](READ_MEDIA_[A-Z_]+|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE|MANAGE_EXTERNAL_STORAGE)'" "$BADGING"; then
  fail "Unexpected broad media/storage permission."
fi
pass "APK package, SDK, version, permission, and launcher metadata verified"

mapfile -t dex_entries < <(zipinfo -1 "$APK" | grep -E '^classes([0-9]+)?[.]dex$' || true)
[[ ${#dex_entries[@]} -gt 0 ]] || fail "APK contains no classes.dex files."
: > "$DEX_CLASSES"
for dex_entry in "${dex_entries[@]}"; do
  dex_file="$DEX_TMP/${dex_entry//\//_}"
  if ! unzip -p "$APK" "$dex_entry" > "$dex_file"; then
    fail "Could not extract $dex_entry from the APK."
  fi
  if ! "$DEXDUMP" -f "$dex_file" >> "$DEX_CLASSES"; then
    fail "dexdump failed for $dex_entry."
  fi
done

for descriptor in \
  'Lcom/govind/personalvault/security/SecurityManager;' \
  'Lcom/govind/personalvault/data/VaultDb;' \
  'Lcom/govind/personalvault/MediaVaultActivity;' \
  'Lcom/govind/personalvault/SecureMediaPlayerActivity;' \
  'Lcom/govind/personalvault/media/EncryptedCipherDataSource;'; do
  grep -Fq "$descriptor" "$DEX_CLASSES" || \
    fail "Required class is missing from APK: $descriptor"
done
pass "Required Phase 2 classes verified in DEX"

sha256sum "$APK"
printf 'PASS: signed Phase 2 APK verified: %s (code %s)\n' \
  "$OUTPUT_APK_NAME" "$VERSION_CODE"
