# Tablet-only GitHub build guide — Govind Personal Vault 1.1.0

The public source ZIP contains no signing keystore or signing password. Keep the separate private signing kit offline.

## Upgrade the existing repository

1. Open the `Govind-Personal-Vault` repository in Chrome.
2. In **Code**, delete the old `Govind_Personal_Vault_GitHub_Public_Repo_v1.0.1_FutureProof.zip` and commit.
3. Upload `Govind_Personal_Vault_GitHub_Public_Repo_v1.1.0_FutureProof.zip` and commit.
4. Replace `.github/workflows/build-apk.yml` with the supplied new workflow file because v1.1.0 migrated to Gradle/Media3.
5. Do not change or delete the existing four repository secrets.

## Build the signed APK

1. Open **Actions**.
2. Select **Build signed APK**.
3. Tap **Run workflow**, keep branch `main`, and tap the green button.
4. Wait for a green **Success** result.
5. Download artifact `Govind-Personal-Vault-v1.1.0`.
6. Extract it and open `Govind_Personal_Vault_v1.1.0.apk`.
7. Choose **Update**. Do not uninstall the existing app.

## If the build fails

Open the failed run, open the red `build` job, expand the first failed step, and share only that error text/screenshot. Never share secret values.
