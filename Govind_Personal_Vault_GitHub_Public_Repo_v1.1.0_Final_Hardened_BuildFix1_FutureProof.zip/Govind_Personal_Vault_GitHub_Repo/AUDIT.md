# Govind Personal Vault 1.1.0 — Phase 2 Security Audit

## Implemented controls

### Process and network surface

- Manifest has no Internet permission and cleartext traffic is disabled.
- Cloud backup and device-transfer extraction are disabled.
- All app activities except the launcher are non-exported.
- No broad media/storage permission is requested; the system document picker grants access only to selected URIs.
- All activities apply `FLAG_SECURE` before rendering.

### Runtime key model

- Phase 2 continues to obtain the unlocked vault master key only through `VaultSession.requireKeyCopy()`.
- Each media file uses random salt and HKDF-SHA256 to derive separate content and header-MAC keys.
- Temporary key copies, decrypted chunks, thumbnails, and transfer buffers are wiped when practical.
- The VMK remains process-memory-only and is wiped when the app task enters the background.

### GVM2 encrypted-media format

- Media is stored under private internal app storage only.
- The complete plaintext file is never loaded into RAM.
- Import reads bounded chunks and encrypts each independently with AES-256-GCM.
- Every chunk has a unique random 96-bit IV and AAD binding file identity, format, chunk size, chunk order, and clear chunk length.
- The fixed header is authenticated with a separate HMAC-SHA256 key.
- File length is validated to reject truncation and trailing data.
- Playback/image/export readers use explicit `Cipher.doFinal()` to surface GCM authentication failures.
- The custom Media3 `DataSource` decrypts only the requested bounded chunk and supports seeking without plaintext disk files.

### Database and metadata

- Existing Phase 1 `vault_items` data remains unchanged.
- New `media_items` fields for original name, MIME type, size, and thumbnail are encrypted with contextual AAD.
- Only media UUID and timestamps remain plaintext for identity/indexing.
- Encrypted file paths are derived from UUID rather than stored in SQLite.
- Database work remains serialized on one background executor.

### Import/export/delete

- Import writes a `.part` file, syncs it, then moves it to the final internal path.
- Metadata is committed only after encryption succeeds; failure removes temporary/final artifacts.
- Export decrypts directly to a pending MediaStore row, deletes incomplete rows on failure, then publishes with `IS_PENDING=0`.
- Delete moves the encrypted file to `.trash`, removes metadata, then removes the trash file; metadata failure attempts rollback.
- Stale `.part` and `.trash` files are cleaned after 24 hours.

## Deliberate metadata exposure

Media UUID, row timestamps, and record counts are plaintext. Original filename, MIME type, file size, thumbnail, passwords, usernames, URLs, and note contents are encrypted.

## Tested in this workspace

- Existing AES-GCM tamper/AAD and BIP39 checksum suite passed.
- Standalone GVM2 harness passed layout, offset, header-MAC, per-chunk encryption/decryption, and tamper rejection tests.
- Repository-safety scan passed.
- Phase 2 source-security contract passed.
- All shell scripts passed syntax validation.
- All XML resources parsed successfully.
- GitHub workflow YAML parsed successfully.

## Requires GitHub/device confirmation

This workspace did not contain the Android SDK/Gradle dependency cache and could not perform the final Android compile or device playback test. The GitHub workflow must complete successfully before installation. Real-device tests should cover large import, seeking, rotation/background lock, image decode, export, delete, storage exhaustion, and unsupported codec behavior.

## Not claimed

- Protection after unlock on a rooted or malware-controlled device.
- Guaranteed decoding of every codec on every Android device.
- Secure deletion guarantees from flash-storage wear levelling after export or deletion.
- Independent third-party cryptographic certification.
