package com.govind.personalvault.media;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.IOException;
import java.net.URLConnection;
import java.util.Locale;

/** Safely resolves untrusted document-provider metadata. */
public final class MediaMetadataResolver {
    public static final class Metadata {
        public final String displayName;
        public final String mimeType;
        public final long declaredSize;

        Metadata(String displayName, String mimeType, long declaredSize) {
            this.displayName = displayName;
            this.mimeType = mimeType;
            this.declaredSize = declaredSize;
        }
    }

    private MediaMetadataResolver() { }

    public static Metadata resolve(Context context, Uri uri) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        String name = null;
        long size = -1L;
        Cursor cursor = resolver.query(
                uri,
                new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE},
                null,
                null,
                null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int nameColumn = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int sizeColumn = cursor.getColumnIndex(OpenableColumns.SIZE);
                    if (nameColumn >= 0 && !cursor.isNull(nameColumn)) name = cursor.getString(nameColumn);
                    if (sizeColumn >= 0 && !cursor.isNull(sizeColumn)) size = cursor.getLong(sizeColumn);
                }
            } finally {
                cursor.close();
            }
        }

        if (size < 0L) {
            try (AssetFileDescriptor descriptor = resolver.openAssetFileDescriptor(uri, "r")) {
                if (descriptor != null && descriptor.getLength() >= 0L) size = descriptor.getLength();
            } catch (IOException ignored) { }
        }

        String mime = resolver.getType(uri);
        name = sanitizeName(name == null ? "Imported media" : name);
        if (mime == null || mime.trim().isEmpty() || "application/octet-stream".equals(mime)) {
            mime = URLConnection.guessContentTypeFromName(name);
        }
        if (mime == null) {
            String extension = MimeTypeMap.getFileExtensionFromUrl(name);
            if (extension != null) mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase(Locale.ROOT));
        }
        if (mime == null) throw new IOException("The selected file type could not be identified");
        mime = mime.toLowerCase(Locale.ROOT).trim();
        if (!(mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/"))) {
            throw new IOException("Only image, video, and audio files can be imported");
        }
        if (size == 0L) throw new IOException("Empty media files cannot be imported");
        return new Metadata(name, mime, size);
    }

    public static String sanitizeName(String value) {
        String source = value == null ? "Imported media" : value;
        StringBuilder clean = new StringBuilder(Math.min(180, source.length()));
        for (int index = 0; index < source.length() && clean.length() < 180; index++) {
            char c = source.charAt(index);
            if (c == '/' || c == '\\' || c == 0 || Character.isISOControl(c)) clean.append('_');
            else clean.append(c);
        }
        String result = clean.toString().trim();
        while (result.startsWith(".")) result = result.substring(1).trim();
        return result.isEmpty() ? "Imported media" : result;
    }
}
