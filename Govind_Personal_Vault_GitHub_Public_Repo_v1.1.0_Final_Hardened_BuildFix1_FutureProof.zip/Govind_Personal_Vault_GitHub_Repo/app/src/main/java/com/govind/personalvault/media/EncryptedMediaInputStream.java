package com.govind.personalvault.media;

import android.content.Context;

import com.govind.personalvault.security.VaultSession;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.GeneralSecurityException;
import java.util.UUID;

import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Sequential authenticated plaintext stream for image decoding and MediaStore export. */
public final class EncryptedMediaInputStream extends InputStream {
    private final RandomAccessFile input;
    private final UUID mediaId;
    private final MediaFileFormat.Opened opened;

    private long clearPosition;
    private byte[] clearChunk;
    private int cursor;
    private int limit;
    private long loadedChunk = -1L;
    private boolean closed;

    public static EncryptedMediaInputStream open(Context context, String id)
            throws IOException, GeneralSecurityException {
        UUID mediaId;
        try { mediaId = UUID.fromString(id); }
        catch (IllegalArgumentException invalid) { throw new IOException("Invalid media identifier", invalid); }
        File file = MediaFileFormat.finalFile(context, mediaId);
        RandomAccessFile input = new RandomAccessFile(file, "r");
        try {
            MediaFileFormat.Opened opened = MediaFileFormat.open(input, mediaId);
            return new EncryptedMediaInputStream(input, mediaId, opened);
        } catch (IOException | GeneralSecurityException failure) {
            input.close();
            throw failure;
        }
    }

    private EncryptedMediaInputStream(
            RandomAccessFile input,
            UUID mediaId,
            MediaFileFormat.Opened opened) {
        this.input = input;
        this.mediaId = mediaId;
        this.opened = opened;
    }

    public long clearLength() { return opened.header.clearLength; }

    @Override public int read() throws IOException {
        byte[] one = new byte[1];
        int result = read(one, 0, 1);
        return result < 0 ? -1 : one[0] & 0xff;
    }

    @Override public int read(byte[] buffer, int offset, int length) throws IOException {
        ensureOpen();
        if (buffer == null) throw new NullPointerException("buffer");
        if (offset < 0 || length < 0 || offset > buffer.length - length) throw new IndexOutOfBoundsException();
        if (length == 0) return 0;
        if (clearPosition >= opened.header.clearLength) return -1;
        if (!VaultSession.isUnlocked()) throw new IOException("Vault locked during media read");

        int wanted = (int) Math.min((long) length, opened.header.clearLength - clearPosition);
        int copied = 0;
        while (copied < wanted) {
            long chunkIndex = clearPosition / opened.header.chunkSize;
            int inside = (int) (clearPosition % opened.header.chunkSize);
            if (loadedChunk != chunkIndex || clearChunk == null) loadChunk(chunkIndex);
            cursor = Math.max(cursor, inside);
            int available = limit - cursor;
            if (available <= 0) {
                releaseChunk();
                continue;
            }
            int take = Math.min(wanted - copied, available);
            System.arraycopy(clearChunk, cursor, buffer, offset + copied, take);
            cursor += take;
            clearPosition += take;
            copied += take;
            if (cursor == limit) releaseChunk();
        }
        return copied;
    }

    @Override public long skip(long count) throws IOException {
        ensureOpen();
        if (count <= 0L) return 0L;
        long skipped = Math.min(count, opened.header.clearLength - clearPosition);
        clearPosition += skipped;
        releaseChunk();
        return skipped;
    }

    @Override public int available() throws IOException {
        ensureOpen();
        return (int) Math.min(Integer.MAX_VALUE, opened.header.clearLength - clearPosition);
    }

    @Override public void close() throws IOException {
        if (closed) return;
        closed = true;
        releaseChunk();
        opened.close();
        input.close();
    }

    private void loadChunk(long chunkIndex) throws IOException {
        releaseChunk();
        int clearLength = MediaFileFormat.clearChunkLength(
                opened.header.clearLength,
                opened.header.chunkSize,
                chunkIndex);
        long offset = MediaFileFormat.recordOffset(opened.header.chunkSize, chunkIndex);
        byte[] iv = new byte[MediaFileFormat.IV_BYTES];
        byte[] encrypted = new byte[clearLength + MediaFileFormat.TAG_BYTES];
        byte[] aad = null;
        byte[] decrypted = null;
        try {
            input.seek(offset);
            input.readFully(iv);
            int storedLength = input.readInt();
            if (storedLength != clearLength) throw new IOException("Encrypted media chunk length is invalid");
            input.readFully(encrypted);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(
                    Cipher.DECRYPT_MODE,
                    new SecretKeySpec(opened.keys.contentKey, "AES"),
                    new GCMParameterSpec(128, iv));
            aad = MediaFileFormat.chunkAad(mediaId, opened.header.chunkSize, chunkIndex, storedLength);
            cipher.updateAAD(aad);
            decrypted = cipher.doFinal(encrypted);
            if (decrypted.length != storedLength) {
                throw new IOException("Decrypted media chunk length is invalid");
            }
            clearChunk = decrypted;
            decrypted = null;
            cursor = 0;
            limit = clearChunk.length;
            loadedChunk = chunkIndex;
        } catch (AEADBadTagException tampered) {
            throw new IOException("Encrypted media failed authentication", tampered);
        } catch (GeneralSecurityException failure) {
            throw new IOException("Encrypted media could not be decrypted", failure);
        } finally {
            MediaFileFormat.wipe(iv, encrypted, aad, decrypted);
        }
    }

    private void releaseChunk() {
        MediaFileFormat.wipe(clearChunk);
        clearChunk = null;
        cursor = 0;
        limit = 0;
        loadedChunk = -1L;
    }

    private void ensureOpen() throws IOException {
        if (closed) throw new IOException("Encrypted media stream is closed");
    }
}
