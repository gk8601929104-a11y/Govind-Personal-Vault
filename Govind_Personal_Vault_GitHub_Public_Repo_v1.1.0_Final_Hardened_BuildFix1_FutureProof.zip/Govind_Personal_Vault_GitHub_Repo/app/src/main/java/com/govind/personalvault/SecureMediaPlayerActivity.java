package com.govind.personalvault;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import com.govind.personalvault.data.VaultDb;
import com.govind.personalvault.media.EncryptedCipherDataSource;
import com.govind.personalvault.media.MediaRepository;
import com.govind.personalvault.model.MediaItemRecord;
import com.govind.personalvault.security.VaultSession;
import com.govind.personalvault.ui.Ui;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Fully programmatic Media3 player for authenticated encrypted-media streaming.
 *
 * <p>No decrypted media file is written to disk or shared with another app. The activity uses a
 * secure SurfaceView for video, a programmatic audio-only state, safe Media3 error mapping,
 * programmatic audio-track selection, and an ACTION_SCREEN_OFF receiver that immediately locks the
 * vault and releases player/decoder buffers.
 */
@UnstableApi
public final class SecureMediaPlayerActivity extends BaseActivity {
    private static final long PROGRESS_INTERVAL_MS = 500L;
    private static final long SEEK_STEP_MS = 10_000L;

    private final Handler progressHandler = new Handler(Looper.getMainLooper());
    private final ArrayList<AudioChoice> audioChoices = new ArrayList<>();

    private final Runnable progressTick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            if (player != null) {
                progressHandler.postDelayed(this, PROGRESS_INTERVAL_MS);
            }
        }
    };

    private final BroadcastReceiver screenOffReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!Intent.ACTION_SCREEN_OFF.equals(intent == null ? null : intent.getAction())) {
                return;
            }

            active = false;
            cancelOutstandingTasks();

            // Invalidate the VMK and every epoch-bound media DataSource before releasing the player.
            VaultSession.lock();
            BaseActivity.clearSensitiveClipboard(SecureMediaPlayerActivity.this);
            clearSensitiveUi();
            finish();
        }
    };

    private String mediaId;
    private TextView title;
    private TextView detail;
    private TextView audioArt;
    private SurfaceView surface;
    private SeekBar seek;
    private TextView elapsed;
    private TextView duration;
    private Button play;
    private Button speed;
    private Button audioTrackButton;

    private MediaItemRecord record;
    private VaultDb.Task metadataTask;
    private MediaRepository.Task actionTask;
    private ExoPlayer player;
    private Dialog audioTrackDialog;

    private boolean scrubbing;
    private boolean active;
    private boolean screenReceiverRegistered;
    private int speedIndex;

    private final float[] speeds = new float[]{1.0f, 1.25f, 1.5f, 2.0f};

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        mediaId = getIntent().getStringExtra("media_id");
        if (mediaId == null || mediaId.trim().isEmpty()) {
            finish();
            return;
        }

        build();
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerScreenOffReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        active = VaultSession.isUnlocked();
        if (active) {
            loadMetadata();
        }
    }

    @Override
    protected void onStop() {
        active = false;
        unregisterScreenOffReceiver();
        dismissAudioTrackDialog();
        releasePlayer();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        unregisterScreenOffReceiver();
        cancelOutstandingTasks();
        clearSensitiveUi();
        super.onDestroy();
    }

    @Override
    protected void clearSensitiveUi() {
        dismissAudioTrackDialog();
        releasePlayer();

        if (record != null) {
            record.clearSensitive();
        }
        record = null;

        if (title != null) {
            title.setText("Secure player");
        }
        if (detail != null) {
            detail.setText("Vault locked");
        }
    }

    private void build() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(palette.bg);
        root.addView(topBar(
                "Secure media player",
                "Authenticated playback without plaintext files",
                true,
                null,
                null));

        LinearLayout labels = Ui.vertical(this);
        labels.setPadding(
                Ui.dp(this, 16),
                Ui.dp(this, 8),
                Ui.dp(this, 16),
                Ui.dp(this, 8));

        title = Ui.heading(this, "Opening encrypted media…");
        detail = Ui.text(this, "Preparing authenticated stream", 13, palette.muted);
        labels.addView(title);
        labels.addView(detail, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        root.addView(labels);

        FrameLayout stage = new FrameLayout(this);
        stage.setBackgroundColor(Color.BLACK);

        surface = new SurfaceView(this);
        surface.setSecure(true);
        stage.addView(surface, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        audioArt = Ui.text(this, "♫", 78, palette.accent);
        audioArt.setGravity(Gravity.CENTER);
        audioArt.setBackgroundColor(palette.surface);
        audioArt.setVisibility(View.GONE);
        stage.addView(audioArt, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        root.addView(stage, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        LinearLayout controls = Ui.vertical(this);
        controls.setPadding(
                Ui.dp(this, 14),
                Ui.dp(this, 10),
                Ui.dp(this, 14),
                Ui.dp(this, 10));
        controls.setBackgroundColor(palette.surface);

        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.setEnabled(false);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                ExoPlayer current = player;
                if (fromUser && current != null && current.getDuration() > 0L) {
                    elapsed.setText(formatTime(current.getDuration() * value / 1000L));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                scrubbing = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                ExoPlayer current = player;
                if (current != null && current.getDuration() > 0L) {
                    current.seekTo(current.getDuration() * seekBar.getProgress() / 1000L);
                }
                scrubbing = false;
            }
        });
        controls.addView(seek);

        LinearLayout times = Ui.horizontal(this);
        elapsed = Ui.text(this, "0:00", 12, palette.muted);
        duration = Ui.text(this, "0:00", 12, palette.muted);
        duration.setGravity(Gravity.END);
        times.addView(elapsed, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        times.addView(duration, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        controls.addView(times);

        LinearLayout transport = Ui.horizontal(this);

        Button back = Ui.secondary(this, "−10s");
        back.setOnClickListener(v -> seekBy(-SEEK_STEP_MS));

        play = Ui.primary(this, "Play");
        play.setEnabled(false);
        play.setOnClickListener(v -> togglePlayback());

        Button forward = Ui.secondary(this, "+10s");
        forward.setOnClickListener(v -> seekBy(SEEK_STEP_MS));

        speed = Ui.secondary(this, "1×");
        speed.setOnClickListener(v -> cycleSpeed());

        addControl(transport, back, 0);
        addControl(transport, play, 7);
        addControl(transport, forward, 7);
        addControl(transport, speed, 7);
        controls.addView(transport, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));

        audioTrackButton = Ui.secondary(this, "Audio tracks");
        audioTrackButton.setVisibility(View.GONE);
        audioTrackButton.setContentDescription("Choose audio track");
        audioTrackButton.setOnClickListener(v -> showAudioTrackDialog());
        controls.addView(
                audioTrackButton,
                Ui.margins(this, Ui.MATCH, Ui.dp(this, 48), 0, 8, 0, 0));

        LinearLayout actions = Ui.horizontal(this);

        Button export = Ui.secondary(this, "Export copy");
        export.setOnClickListener(v -> export());

        Button delete = Ui.danger(this, "Delete");
        delete.setOnClickListener(v -> startActivity(
                new Intent(this, MediaDeleteConfirmActivity.class)
                        .putExtra("media_id", mediaId)));

        actions.addView(export, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1));

        LinearLayout.LayoutParams deleteParams =
                new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1);
        deleteParams.leftMargin = Ui.dp(this, 8);
        actions.addView(delete, deleteParams);

        controls.addView(actions, Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 9, 0, 0));
        root.addView(controls);

        safeContentView(root);
    }

    private void addControl(LinearLayout row, Button button, int leftMarginDp) {
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1);
        params.leftMargin = Ui.dp(this, leftMarginDp);
        row.addView(button, params);
    }

    private void loadMetadata() {
        if (metadataTask != null) {
            metadataTask.cancel();
        }

        metadataTask = VaultDb.get(this).getMediaAsync(mediaId, (item, error) -> {
            metadataTask = null;

            if (!active) {
                if (item != null) {
                    item.clearSensitive();
                }
                return;
            }

            if (error != null) {
                SecureMediaPlayerActivity.this.error(error);
                finish();
                return;
            }

            if (item == null) {
                message("Media no longer exists");
                finish();
                return;
            }

            if (item.isImage()) {
                item.clearSensitive();
                startActivity(
                        new Intent(this, SecureImageViewerActivity.class)
                                .putExtra("media_id", mediaId));
                finish();
                return;
            }

            if (record != null) {
                record.clearSensitive();
            }
            record = item;

            title.setText(record.originalName);
            detail.setText(record.mimeType + " • " + humanSize(record.size));
            surface.setVisibility(record.isVideo() ? View.VISIBLE : View.GONE);
            audioArt.setVisibility(record.isAudio() ? View.VISIBLE : View.GONE);

            initializePlayer();
        });
    }

    private void initializePlayer() {
        releasePlayer();

        if (record == null || !VaultSession.isUnlocked()) {
            return;
        }

        EncryptedCipherDataSource.Factory encryptedFactory =
                new EncryptedCipherDataSource.Factory(this);

        DefaultMediaSourceFactory mediaSources =
                new DefaultMediaSourceFactory(this)
                        .setDataSourceFactory(encryptedFactory);

        ExoPlayer created = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSources)
                .build();

        player = created;
        created.setVideoSurfaceView(surface);
        created.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (player == created && play != null) {
                    play.setText(isPlaying ? "Pause" : "Play");
                }
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (player != created) {
                    return;
                }

                if (state == Player.STATE_READY) {
                    play.setEnabled(true);
                    seek.setEnabled(true);
                    updateProgress();
                } else if (state == Player.STATE_ENDED) {
                    play.setText("Replay");
                }
            }

            @Override
            public void onTracksChanged(Tracks tracks) {
                if (player == created) {
                    handleTracks(tracks);
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (player != created) {
                    return;
                }

                String userMessage = mapPlaybackError(error);
                releasePlayer();
                detail.setText(userMessage);
                message(userMessage);
            }
        });

        Uri secureUri = Uri.parse(
                EncryptedCipherDataSource.URI_SCHEME + "://media/" + mediaId);

        MediaItem mediaItem = new MediaItem.Builder()
                .setUri(secureUri)
                .setMimeType(record.mimeType)
                .setMediaId(mediaId)
                .build();

        created.setMediaItem(mediaItem);
        created.prepare();
        progressHandler.post(progressTick);
    }

    private void handleTracks(Tracks tracks) {
        if (record == null || player == null) {
            return;
        }

        audioChoices.clear();

        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() != C.TRACK_TYPE_AUDIO) {
                continue;
            }

            TrackGroup mediaGroup = group.mediaTrackGroup;
            for (int trackIndex = 0; trackIndex < group.length; trackIndex++) {
                audioChoices.add(new AudioChoice(
                        mediaGroup,
                        trackIndex,
                        group.getTrackFormat(trackIndex),
                        group.isTrackSupported(trackIndex, true),
                        group.isTrackSelected(trackIndex)));
            }
        }

        if (record.isVideo()
                && tracks.containsType(C.TRACK_TYPE_VIDEO)
                && !tracks.isTypeSupported(C.TRACK_TYPE_VIDEO, true)) {
            failUnsupportedPlayback(
                    "This video's codec is not supported on this device.");
            return;
        }

        if (record.isAudio()
                && tracks.containsType(C.TRACK_TYPE_AUDIO)
                && !tracks.isTypeSupported(C.TRACK_TYPE_AUDIO, true)) {
            failUnsupportedPlayback(
                    "This audio codec is not supported on this device.");
            return;
        }

        updateAudioTrackButton();
    }

    private void updateAudioTrackButton() {
        if (audioTrackButton == null) {
            return;
        }

        int supportedCount = 0;
        AudioChoice selected = null;

        for (AudioChoice choice : audioChoices) {
            if (choice.supported) {
                supportedCount++;
            }
            if (choice.selected) {
                selected = choice;
            }
        }

        if (audioChoices.size() <= 1 || supportedCount == 0) {
            audioTrackButton.setVisibility(View.GONE);
            return;
        }

        audioTrackButton.setVisibility(View.VISIBLE);
        audioTrackButton.setText(
                selected == null
                        ? "Audio tracks"
                        : "Audio: " + shortAudioLabel(selected.format));
    }

    private void showAudioTrackDialog() {
        ExoPlayer current = player;
        if (current == null || audioChoices.size() <= 1) {
            return;
        }

        dismissAudioTrackDialog();

        Dialog dialog = new Dialog(this);
        audioTrackDialog = dialog;

        LinearLayout root = Ui.vertical(this);
        root.setPadding(
                Ui.dp(this, 18),
                Ui.dp(this, 18),
                Ui.dp(this, 18),
                Ui.dp(this, 14));
        root.setBackground(Ui.roundRect(this, palette.surface, 20, 1, palette.line));

        root.addView(Ui.heading(this, "Audio track"));
        root.addView(
                Ui.text(
                        this,
                        "Switch between the audio streams stored inside this media file.",
                        13,
                        palette.muted),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 12));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        RadioGroup choicesView = new RadioGroup(this);
        choicesView.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(choicesView, new ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP));

        RadioButton automatic = createTrackRadio("Automatic selection", true);
        automatic.setId(View.generateViewId());
        automatic.setOnClickListener(v -> {
            ExoPlayer activePlayer = player;
            if (activePlayer != null) {
                TrackSelectionParameters parameters =
                        activePlayer.getTrackSelectionParameters()
                                .buildUpon()
                                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                .build();
                activePlayer.setTrackSelectionParameters(parameters);
            }
            dialog.dismiss();
        });
        choicesView.addView(automatic, trackRowParams());

        int number = 1;
        boolean selectedAssigned = false;

        for (AudioChoice choice : audioChoices) {
            String label = audioLabel(number++, choice);
            RadioButton row = createTrackRadio(label, choice.supported);
            row.setId(View.generateViewId());
            row.setChecked(choice.selected);
            if (choice.selected) {
                selectedAssigned = true;
            }

            row.setOnClickListener(v -> {
                ExoPlayer activePlayer = player;
                if (activePlayer != null && choice.supported) {
                    TrackSelectionOverride override =
                            new TrackSelectionOverride(
                                    choice.group,
                                    choice.trackIndex);

                    TrackSelectionParameters parameters =
                            activePlayer.getTrackSelectionParameters()
                                    .buildUpon()
                                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                    .setOverrideForType(override)
                                    .build();

                    activePlayer.setTrackSelectionParameters(parameters);
                }
                dialog.dismiss();
            });

            choicesView.addView(row, trackRowParams());
        }

        if (!selectedAssigned) {
            automatic.setChecked(true);
        }

        root.addView(
                scroll,
                new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 360)));

        Button close = Ui.secondary(this, "Close");
        close.setOnClickListener(v -> dialog.dismiss());
        root.addView(close, Ui.margins(this, Ui.MATCH, Ui.dp(this, 48), 0, 12, 0, 0));

        dialog.setContentView(root);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnDismissListener(ignored -> {
            if (audioTrackDialog == dialog) {
                audioTrackDialog = null;
            }
        });
        dialog.show();

        Window window = dialog.getWindow();
        if (window != null) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int availableWidth =
                    getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 32);
            int width = Math.min(availableWidth, Ui.dp(this, 560));
            window.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private RadioButton createTrackRadio(String text, boolean enabled) {
        RadioButton button = new RadioButton(this);
        button.setText(text);
        button.setTextSize(15);
        button.setTextColor(enabled ? palette.text : palette.muted);
        button.setEnabled(enabled);
        button.setGravity(Gravity.CENTER_VERTICAL);
        button.setPadding(
                Ui.dp(this, 8),
                Ui.dp(this, 8),
                Ui.dp(this, 8),
                Ui.dp(this, 8));
        return button;
    }

    private LinearLayout.LayoutParams trackRowParams() {
        return new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
    }

    private void failUnsupportedPlayback(String userMessage) {
        releasePlayer();
        detail.setText(userMessage);
        message(userMessage);
    }

    private void releasePlayer() {
        progressHandler.removeCallbacks(progressTick);
        dismissAudioTrackDialog();

        ExoPlayer current = player;
        player = null;

        if (current != null) {
            try {
                if (surface != null) {
                    current.clearVideoSurfaceView(surface);
                }
            } catch (RuntimeException ignored) {
                // Continue to release the player even if the surface was already detached.
            }

            try {
                current.release();
            } catch (RuntimeException ignored) {
                // The reference is already detached; do not allow a release failure to retain UI data.
            }
        }

        audioChoices.clear();
        speedIndex = 0;
        scrubbing = false;

        if (audioTrackButton != null) {
            audioTrackButton.setText("Audio tracks");
            audioTrackButton.setVisibility(View.GONE);
        }
        if (speed != null) {
            speed.setText("1×");
        }
        if (play != null) {
            play.setText("Play");
            play.setEnabled(false);
        }
        if (seek != null) {
            seek.setProgress(0);
            seek.setEnabled(false);
        }
        if (elapsed != null) {
            elapsed.setText("0:00");
        }
        if (duration != null) {
            duration.setText("0:00");
        }
    }

    private void dismissAudioTrackDialog() {
        Dialog dialog = audioTrackDialog;
        audioTrackDialog = null;
        if (dialog != null && dialog.isShowing()) {
            try {
                dialog.dismiss();
            } catch (RuntimeException ignored) {
                // The window may already have been detached during lifecycle teardown.
            }
        }
    }

    private void togglePlayback() {
        ExoPlayer current = player;
        if (current == null || !VaultSession.isUnlocked()) {
            return;
        }

        if (current.getPlaybackState() == Player.STATE_ENDED) {
            current.seekTo(0L);
        }

        if (current.isPlaying()) {
            current.pause();
        } else {
            current.play();
        }
    }

    private void seekBy(long delta) {
        ExoPlayer current = player;
        if (current == null) {
            return;
        }

        long durationValue = current.getDuration();
        long target = Math.max(0L, current.getCurrentPosition() + delta);
        if (durationValue > 0L) {
            target = Math.min(durationValue, target);
        }
        current.seekTo(target);
    }

    private void cycleSpeed() {
        speedIndex = (speedIndex + 1) % speeds.length;
        float value = speeds[speedIndex];

        speed.setText(String.format(
                Locale.US,
                "%s×",
                value == Math.round(value)
                        ? Integer.toString(Math.round(value))
                        : Float.toString(value)));

        ExoPlayer current = player;
        if (current != null) {
            current.setPlaybackSpeed(value);
        }
    }

    private void updateProgress() {
        ExoPlayer current = player;
        if (current == null || scrubbing) {
            return;
        }

        long durationValue = current.getDuration();
        long position = Math.max(0L, current.getCurrentPosition());

        if (durationValue > 0L) {
            seek.setProgress((int) Math.min(1000L, position * 1000L / durationValue));
        }

        elapsed.setText(formatTime(position));
        duration.setText(formatTime(Math.max(0L, durationValue)));
    }

    private void export() {
        if (record == null || actionTask != null || !VaultSession.isUnlocked()) {
            return;
        }

        message("Exporting authenticated copy…");
        actionTask = MediaRepository.exportAsync(this, mediaId, (uri, error) -> {
            actionTask = null;
            if (!active) {
                return;
            }

            if (error != null) {
                SecureMediaPlayerActivity.this.error(error);
            } else {
                message("Exported to the device gallery");
            }
        });
    }

    private void cancelOutstandingTasks() {
        if (metadataTask != null) {
            metadataTask.cancel();
            metadataTask = null;
        }
        if (actionTask != null) {
            actionTask.cancel();
            actionTask = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void registerScreenOffReceiver() {
        if (screenReceiverRegistered) {
            return;
        }

        try {
            registerReceiver(
                    screenOffReceiver,
                    new IntentFilter(Intent.ACTION_SCREEN_OFF));
            screenReceiverRegistered = true;
        } catch (RuntimeException ignored) {
            screenReceiverRegistered = false;
        }
    }

    private void unregisterScreenOffReceiver() {
        if (!screenReceiverRegistered) {
            return;
        }

        screenReceiverRegistered = false;
        try {
            unregisterReceiver(screenOffReceiver);
        } catch (RuntimeException ignored) {
            // Receiver may already have been removed by framework teardown.
        }
    }

    private String mapPlaybackError(PlaybackException error) {
        if (!VaultSession.isUnlocked()) {
            return "Vault locked. Unlock it to play this media.";
        }

        switch (error.errorCode) {
            case PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED:
                return "This media container is not supported on this device.";

            case PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED:
                return "This media file is damaged or has an invalid container.";

            case PlaybackException.ERROR_CODE_DECODER_INIT_FAILED:
            case PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED:
                return "The device could not start a decoder for this media.";

            case PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED:
                return "This audio or video codec is not supported on this device.";

            case PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES:
                return "This media exceeds the device's playback capabilities.";

            case PlaybackException.ERROR_CODE_DECODING_FAILED:
                return "The device could not decode this media securely.";

            case PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND:
                return "The encrypted media file is missing.";

            case PlaybackException.ERROR_CODE_IO_NO_PERMISSION:
                return "The encrypted media file could not be accessed.";

            case PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE:
            case PlaybackException.ERROR_CODE_IO_UNSPECIFIED:
                return "Secure media authentication or reading failed.";

            default:
                return "Secure playback could not continue.";
        }
    }

    private static String audioLabel(int number, AudioChoice choice) {
        StringBuilder label = new StringBuilder("Track ").append(number);
        Format format = choice.format;

        if (format.label != null && !format.label.trim().isEmpty()) {
            label.append(" • ").append(format.label.trim());
        } else {
            String language = displayLanguage(format.language);
            if (!language.isEmpty()) {
                label.append(" • ").append(language);
            }
        }

        if (format.channelCount > 0) {
            label.append(" • ").append(format.channelCount).append(" ch");
        }

        if (format.sampleMimeType != null && !format.sampleMimeType.trim().isEmpty()) {
            label.append(" • ").append(format.sampleMimeType.trim());
        }

        if (!choice.supported) {
            label.append(" • Unsupported");
        }

        return label.toString();
    }

    private static String shortAudioLabel(Format format) {
        if (format.label != null && !format.label.trim().isEmpty()) {
            return format.label.trim();
        }

        String language = displayLanguage(format.language);
        if (!language.isEmpty()) {
            return language;
        }

        return format.channelCount > 0
                ? format.channelCount + " ch"
                : "Selected";
    }

    private static String displayLanguage(String languageTag) {
        if (languageTag == null) {
            return "";
        }

        String trimmed = languageTag.trim();
        if (trimmed.isEmpty() || "und".equalsIgnoreCase(trimmed)) {
            return "";
        }

        Locale locale = Locale.forLanguageTag(trimmed);
        String value = locale.getDisplayLanguage();
        return value == null || value.trim().isEmpty() ? trimmed : value;
    }

    private static String formatTime(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;

        return hours > 0L
                ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
                : String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private static String humanSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }

        double kb = bytes / 1024.0;
        if (kb < 1024.0) {
            return String.format(Locale.US, "%.1f KB", kb);
        }

        double mb = kb / 1024.0;
        if (mb < 1024.0) {
            return String.format(Locale.US, "%.1f MB", mb);
        }

        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }

    private static final class AudioChoice {
        final TrackGroup group;
        final int trackIndex;
        final Format format;
        final boolean supported;
        final boolean selected;

        AudioChoice(
                TrackGroup group,
                int trackIndex,
                Format format,
                boolean supported,
                boolean selected) {
            this.group = group;
            this.trackIndex = trackIndex;
            this.format = format;
            this.supported = supported;
            this.selected = selected;
        }
    }
}
