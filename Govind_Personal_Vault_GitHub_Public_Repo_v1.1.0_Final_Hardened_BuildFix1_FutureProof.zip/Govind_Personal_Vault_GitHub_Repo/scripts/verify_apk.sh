#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=version_config.sh
source "$SCRIPT_DIR/version_config.sh"

APK="$OUTPUT_APK"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"

if [[ -z "$SDK_DIR" || ! -f "$APK" ]]; then
  echo "Build the APK and set ANDROID_SDK_ROOT first." >&2
  exit 1
fi

BUILD_TOOLS_DIR="$SDK_DIR/build-tools/$BUILD_TOOLS_VERSION"
AAPT2="$BUILD_TOOLS_DIR/aapt2"
APKSIGNER="$BUILD_TOOLS_DIR/apksigner"
ZIPALIGN="$BUILD_TOOLS_DIR/zipalign"
DEXDUMP="$BUILD_TOOLS_DIR/dexdump"
BADGING="$PROJECT_DIR/app/build/apk-badging.txt"
MANIFEST_TREE="$PROJECT_DIR/app/build/apk-manifest.txt"
DEX_CLASSES="$PROJECT_DIR/app/build/apk-classes.txt"

for required in "$AAPT2" "$APKSIGNER" "$ZIPALIGN" "$DEXDUMP"; do
  [[ -f "$required" ]] || { echo "Required Android build tool is missing: $required" >&2; exit 1; }
done

"$APKSIGNER" verify --verbose --print-certs "$APK"
"$ZIPALIGN" -c -v 4 "$APK" >/dev/null
unzip -t "$APK" >/dev/null
"$AAPT2" dump badging "$APK" > "$BADGING"
"$AAPT2" dump xmltree "$APK" --file AndroidManifest.xml > "$MANIFEST_TREE"
"$DEXDUMP" -f "$APK" > "$DEX_CLASSES"

grep -q "package: name='com.govind.personalvault'" "$BADGING"
grep -q "minSdkVersion:'$MIN_SDK'" "$BADGING"
grep -q "targetSdkVersion:'$TARGET_SDK'" "$BADGING"
grep -q "versionCode='$VERSION_CODE' versionName='$VERSION_NAME'" "$BADGING"
grep -q "uses-permission: name='android.permission.USE_BIOMETRIC'" "$BADGING"
if grep -q "android.permission.INTERNET" "$BADGING"; then echo "Unexpected INTERNET permission." >&2; exit 1; fi
if rg -n "READ_MEDIA_|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE|MANAGE_EXTERNAL_STORAGE" "$BADGING" >/dev/null; then
  echo "Unexpected broad media/storage permission." >&2; exit 1
fi
grep -q 'android:name.*=".MainActivity"' "$MANIFEST_TREE"
grep -q 'android:exported.*=true' "$MANIFEST_TREE"
grep -q 'Class descriptor.*Lcom/govind/personalvault/security/SecurityManager;' "$DEX_CLASSES"
grep -q 'Class descriptor.*Lcom/govind/personalvault/data/VaultDb;' "$DEX_CLASSES"
grep -q 'Class descriptor.*Lcom/govind/personalvault/MediaVaultActivity;' "$DEX_CLASSES"
grep -q 'Class descriptor.*Lcom/govind/personalvault/SecureMediaPlayerActivity;' "$DEX_CLASSES"
grep -q 'Class descriptor.*Lcom/govind/personalvault/media/EncryptedCipherDataSource;' "$DEX_CLASSES"
sha256sum "$APK"
printf 'PASS: signed Phase 2 APK verified: %s (code %s)\n' "$OUTPUT_APK_NAME" "$VERSION_CODE"
