#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
command -v gradle >/dev/null || {
  echo "Gradle is not installed on PATH." >&2
  exit 1
}

GRADLE=(gradle --no-daemon --stacktrace -p "$PROJECT_DIR")

# Always compile the production Java sources and run release lint. This catches
# source/API/resource/manifest problems even when the project currently has no
# app/src/test sources and AGP therefore creates no release unit-test task.
"${GRADLE[@]}" :app:compileReleaseJavaWithJavac :app:lintRelease

# Future-proof behavior: automatically run release unit tests whenever that
# task exists, but do not fail merely because a source package has no unit-test
# variant/task yet.
if gradle --no-daemon --console=plain -q -p "$PROJECT_DIR" :app:tasks --all \
    | grep -Eq '^testReleaseUnitTest([[:space:]-]|$)'; then
  "${GRADLE[@]}" :app:testReleaseUnitTest
else
  echo "INFO: :app:testReleaseUnitTest is not available; production compile and release lint passed."
fi
