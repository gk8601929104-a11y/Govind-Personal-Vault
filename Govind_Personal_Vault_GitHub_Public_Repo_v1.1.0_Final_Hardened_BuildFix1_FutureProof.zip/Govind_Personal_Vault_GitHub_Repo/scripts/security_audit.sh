#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=version_config.sh
source "$SCRIPT_DIR/version_config.sh"

MANIFEST="$PROJECT_DIR/app/src/main/AndroidManifest.xml"
JAVA_DIR="$PROJECT_DIR/app/src/main/java"
GRADLE_FILE="$PROJECT_DIR/app/build.gradle"

rg -q "applicationId packageId" "$GRADLE_FILE"
rg -q "androidx.media3:media3-exoplayer" "$GRADLE_FILE"
rg -q "androidx.activity:activity" "$GRADLE_FILE"
grep -q "android:minSdkVersion=\"$MIN_SDK\"" "$MANIFEST"
grep -q "android:targetSdkVersion=\"$TARGET_SDK\"" "$MANIFEST"
grep -q 'android:allowBackup="false"' "$MANIFEST"
grep -q 'android:usesCleartextTraffic="false"' "$MANIFEST"
grep -q 'android:dataExtractionRules="@xml/data_extraction_rules"' "$MANIFEST"
grep -q 'android.permission.USE_BIOMETRIC' "$MANIFEST"
if grep -q 'android.permission.INTERNET' "$MANIFEST"; then echo "FAIL: Internet permission" >&2; exit 1; fi
if rg -n 'READ_MEDIA_|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE|MANAGE_EXTERNAL_STORAGE' "$MANIFEST" >/dev/null; then
  echo "FAIL: broad storage permission is not allowed" >&2; exit 1
fi

rg -q 'FLAG_SECURE' "$JAVA_DIR/com/govind/personalvault/BaseActivity.java"
rg -q 'extends ComponentActivity' "$JAVA_DIR/com/govind/personalvault/BaseActivity.java"
rg -q 'AES/GCM/NoPadding' "$JAVA_DIR/com/govind/personalvault/security/CryptoBox.java"
rg -q 'PBKDF2WithHmacSHA256' "$JAVA_DIR/com/govind/personalvault/security/SecurityManager.java"
rg -q 'AUTH_BIOMETRIC_STRONG' "$JAVA_DIR/com/govind/personalvault/security/SecurityManager.java"
rg -q 'BiometricPrompt.CryptoObject' "$JAVA_DIR/com/govind/personalvault/LockActivity.java"
rg -q 'newSingleThreadExecutor' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
rg -q 'CREATE TABLE IF NOT EXISTS media_items' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
rg -q 'original_name_blob TEXT NOT NULL' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
rg -q 'thumbnail_blob TEXT NOT NULL' "$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
rg -q 'CipherOutputStream' "$JAVA_DIR/com/govind/personalvault/media/MediaCryptoWriter.java"
rg -q 'extends BaseDataSource' "$JAVA_DIR/com/govind/personalvault/media/EncryptedCipherDataSource.java"
rg -q 'AEADBadTagException' "$JAVA_DIR/com/govind/personalvault/media/EncryptedCipherDataSource.java"
rg -q 'getFilesDir\(\)' "$JAVA_DIR/com/govind/personalvault/media/MediaFileFormat.java"
rg -q 'MediaStore.MediaColumns.IS_PENDING' "$JAVA_DIR/com/govind/personalvault/media/MediaExporter.java"
rg -q 'OpenMultipleDocuments' "$JAVA_DIR/com/govind/personalvault/MediaVaultActivity.java"
rg -q 'ExoPlayer' "$JAVA_DIR/com/govind/personalvault/SecureMediaPlayerActivity.java"
if rg -n 'ACTION_VIEW|Intent\.createChooser|FileProvider' "$JAVA_DIR/com/govind/personalvault" >/dev/null; then
  echo "FAIL: decrypted media must not be handed to external apps" >&2; exit 1
fi
if rg -n 'onSaveInstanceState' "$JAVA_DIR" >/dev/null; then echo "FAIL: sensitive state must not use Bundles" >&2; exit 1; fi
if rg -n 'com\.govind\.smartcalc|govind_smart_calculator' "$PROJECT_DIR/app" >/dev/null; then echo "FAIL: calculator identity leaked into vault" >&2; exit 1; fi

# All direct SQLite calls stay inside VaultDb.
db_calls="$(rg -l 'getWritableDatabase|getReadableDatabase|rawQuery\(' "$JAVA_DIR" || true)"
expected="$JAVA_DIR/com/govind/personalvault/data/VaultDb.java"
if [[ "$db_calls" != "$expected" ]]; then echo "FAIL: database access escaped VaultDb" >&2; printf '%s\n' "$db_calls" >&2; exit 1; fi

permission_count="$(rg -c '<uses-permission ' "$MANIFEST")"
if [[ "$permission_count" != "1" ]]; then echo "FAIL: unexpected manifest permission count" >&2; exit 1; fi

printf 'PASS: Phase 2 source security contract for SDK %s/%s, version %s (%s)\n' "$MIN_SDK" "$TARGET_SDK" "$VERSION_NAME" "$VERSION_CODE"
